import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    )

    // Salvar DIRETO no Supabase sem complicações
    const { data, error } = await supabase.from('orders').insert({
      customer_name: body.customerName,
      phone: body.phone,
      address: body.address,
      items: body.items,
      total: body.total,
    }).select()

    if (error) {
      console.error('[v0] Erro Supabase:', error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ success: true, order: data?.[0] })
  } catch (error) {
    console.error('[v0] Erro ao salvar:', error)
    return NextResponse.json({ error: 'Erro ao salvar pedido' }, { status: 500 })
  }
}

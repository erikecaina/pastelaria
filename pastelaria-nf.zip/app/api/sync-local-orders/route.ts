import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const pendingOrders = body.pendingOrders || []

    if (pendingOrders.length === 0) {
      return NextResponse.json({ synced: 0 })
    }

    const { createClient } = await import('@supabase/supabase-js')
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!url || !key) {
      return NextResponse.json({ error: 'Missing credentials' }, { status: 500 })
    }

    const supabase = createClient(url, key)
    let syncedCount = 0

    for (const order of pendingOrders) {
      const { data, error } = await supabase
        .from('orders')
        .insert([
          {
            customer_name: order.customerName,
            phone: order.phone,
            address: order.address,
            items: order.items,
            total: order.total,
            status: 'pendente',
          },
        ])
        .select()

      if (!error && data) {
        syncedCount++
      }
    }

    return NextResponse.json({ synced: syncedCount })
  } catch (error) {
    console.error('[v0] Error syncing orders:', error)
    return NextResponse.json({ synced: 0 })
  }
}

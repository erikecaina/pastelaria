import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    console.log('[v0] POST /api/save-order - Dados recebidos:', body)

    // Importar Supabase dinâmico
    const { createClient } = await import('@supabase/supabase-js')
    
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!url || !key) {
      return NextResponse.json({ error: 'Credenciais ausentes' }, { status: 500 })
    }

    const supabase = createClient(url, key)

    // Salvar pedido no Supabase
    const { data, error } = await supabase
      .from('orders')
      .insert([
        {
          customer_name: body.customerName,
          phone: body.phone,
          address: body.address,
          items: body.items,
          total: body.total,
          status: 'pendente',
        },
      ])
      .select()

    console.log('[v0] Resposta Supabase:', { data, error })

    if (error) {
      console.error('[v0] Erro Supabase:', error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    const createdOrder = data?.[0]
    console.log('[v0] Pedido criado com sucesso:', createdOrder)

    return NextResponse.json({
      id: createdOrder.id,
      customerName: createdOrder.customer_name,
      total: createdOrder.total,
      message: 'Pedido salvo com sucesso!'
    })
  } catch (error) {
    console.error('[v0] Erro em save-order:', error)
    return NextResponse.json(
      { error: `Erro ao salvar pedido: ${String(error)}` },
      { status: 500 }
    )
  }
}

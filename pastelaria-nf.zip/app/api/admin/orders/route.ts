import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { createClient } = await import('@supabase/supabase-js')
    
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!url || !key) {
      return NextResponse.json({ error: 'Missing credentials' }, { status: 500 })
    }

    const supabase = createClient(url, key)

    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100)

    if (error) throw error

    // Transformar dados para o formato esperado
    const orders = data?.map((order: any) => ({
      id: order.id,
      customer_name: order.customer_name,
      customer_phone: order.phone,
      customer_address: order.address,
      items: typeof order.items === 'string' ? JSON.parse(order.items) : order.items,
      will_pickup: order.will_pickup || false,
      status: order.status || 'pendente',
      created_at: order.created_at,
      updated_at: order.updated_at,
    })) || []

    console.log('[v0] API /api/admin/orders - Retornando', orders.length, 'pedidos')

    return NextResponse.json({ orders })
  } catch (error) {
    console.error('[v0] Erro em /api/admin/orders:', error)
    return NextResponse.json({ error: 'Failed to fetch orders', orders: [] }, { status: 500 })
  }
}

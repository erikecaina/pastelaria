import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const { createClient } = await import('@supabase/supabase-js')
    
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!url || !key) {
      return NextResponse.json({ error: 'Missing credentials' }, { status: 500 })
    }

    const supabase = createClient(url, key)
    const body = await request.json()

    // Tentar salvar com timeout de 5 segundos
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 5000)

    try {
      const { data, error } = await Promise.race([
        supabase
          .from('orders')
          .insert([
            {
              customer_name: body.customerName,
              phone: body.phone,
              address: body.address,
              items: body.items,
              total: body.total,
              status: 'pendente',
            },
          ])
          .select(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Timeout')), 5000)
        ),
      ])

      clearTimeout(timeoutId)

      if (error) throw error

      return NextResponse.json({ 
        success: true,
        order: data?.[0] || {},
        source: 'backup'
      })
    } catch (e) {
      clearTimeout(timeoutId)
      throw e
    }
  } catch (error) {
    console.error('[v0] Error in orders-backup:', error)
    // Retornar sucesso mesmo que falhe (o pedido vai ficar na fila)
    return NextResponse.json({ 
      success: true, 
      cached: true,
      message: 'Pedido será sincronizado em breve'
    })
  }
}

import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { createClient } = await import('@supabase/supabase-js')
    
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!url || !key) {
      return NextResponse.json({ error: 'Missing credentials' }, { status: 500 })
    }

    const supabase = createClient(url, key)

    // Recuperar todos os pedidos pendentes (últimas 24 horas)
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('status', 'pendente')
      .order('created_at', { ascending: false })
      .limit(100)

    if (error) throw error

    return NextResponse.json({ orders: data || [] })
  } catch (error) {
    console.error('[v0] Error fetching orders:', error)
    return NextResponse.json({ orders: [] }, { status: 200 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { createClient } = await import('@supabase/supabase-js')
    
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!url || !key) {
      return NextResponse.json({ error: 'Missing credentials' }, { status: 500 })
    }

    const supabase = createClient(url, key)
    const body = await request.json()

    console.log('[v0] POST /api/orders - salvando pedido:', body.customerName)

    const { data, error } = await supabase
      .from('orders')
      .insert([
        {
          customer_name: body.customerName,
          phone: body.phone,
          address: body.address,
          items: body.items,
          total: body.total,
          status: 'pendente',
        },
      ])
      .select()

    if (error) {
      console.error('[v0] Error inserting order:', error)
      throw error
    }

    console.log('[v0] Pedido salvo com sucesso:', data?.[0]?.id)
    return NextResponse.json({ order: data?.[0] || {}, success: true })
  } catch (error) {
    console.error('[v0] Error in POST /api/orders:', error)
    return NextResponse.json(
      { error: 'Failed to create order', details: String(error), success: false }, 
      { status: 500 }
    )
  }
}

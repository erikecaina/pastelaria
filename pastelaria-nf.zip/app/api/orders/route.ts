import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { createClient } = await import('@supabase/supabase-js')
    
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!url || !key) {
      return NextResponse.json({ error: 'Missing credentials' }, { status: 500 })
    }

    const supabase = createClient(url, key)
    const { data: orders, error } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) throw error

    return NextResponse.json({ orders: orders || [] })
  } catch (error) {
    console.error('[v0] Error fetching orders:', error)
    return NextResponse.json({ error: 'Failed to fetch orders' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { createClient } = await import('@supabase/supabase-js')
    
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    console.log('[v0] POST /api/orders - iniciando salvamento')

    if (!url || !key) {
      console.error('[v0] Missing Supabase credentials')
      return NextResponse.json({ error: 'Missing credentials' }, { status: 500 })
    }

    const supabase = createClient(url, key)
    const body = await request.json()
    
    console.log('[v0] POST /api/orders - dados recebidos:', { 
      customerName: body.customerName,
      phone: body.phone,
      address: body.address?.substring(0, 50),
      itemsCount: body.items?.length,
      total: body.total
    })

    const { data, error } = await supabase
      .from('orders')
      .insert([
        {
          customer_name: body.customerName,
          phone: body.phone,
          address: body.address,
          items: body.items,
          total: body.total,
          status: 'pendente',
        },
      ])
      .select()

    if (error) {
      console.error('[v0] Erro ao salvar no Supabase:', error)
      throw error
    }

    console.log('[v0] Pedido salvo com sucesso:', data?.[0]?.id)
    return NextResponse.json({ order: data?.[0] || {} })
  } catch (error) {
    console.error('[v0] Error creating order:', error)
    return NextResponse.json({ error: 'Failed to create order', details: String(error) }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { createClient } = await import('@supabase/supabase-js')
    
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!url || !key) {
      return NextResponse.json({ error: 'Missing credentials' }, { status: 500 })
    }

    const supabase = createClient(url, key)
    const body = await request.json()
    const { orderId, status } = body

    if (!orderId || !status) {
      return NextResponse.json({ error: 'Missing order ID or status' }, { status: 400 })
    }

    const { data, error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', orderId)
      .select()

    if (error) throw error

    return NextResponse.json(data?.[0] || {})
  } catch (error) {
    console.error('[v0] Error updating order:', error)
    return NextResponse.json({ error: 'Failed to update order' }, { status: 500 })
  }
}

'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'

const ADMIN_PASSWORD = 'admin123'

export default function AdminLoginPage() {
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    console.log('[v0] Login attempt with password:', password === ADMIN_PASSWORD)

    if (password === ADMIN_PASSWORD) {
      localStorage.setItem('admin_authenticated', 'true')
      router.push('/admin/produtos')
      return
    } else {
      setError('Senha incorreta')
      setPassword('')
    }

    setIsLoading(false)
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(to bottom, rgb(220, 38, 38), rgba(220, 38, 38, 0.9))',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '1rem'
    }}>
      <div style={{
        width: '100%',
        maxWidth: '28rem'
      }}>
        <div style={{
          background: 'white',
          borderRadius: '0.5rem',
          boxShadow: '0 10px 25px rgba(0, 0, 0, 0.1)',
          padding: '2rem'
        }}>
          <h1 style={{
            fontSize: '1.875rem',
            fontWeight: 'bold',
            textAlign: 'center',
            marginBottom: '0.5rem',
            color: 'rgb(15, 23, 42)'
          }}>
            Painel Admin
          </h1>
          <p style={{
            textAlign: 'center',
            color: 'rgb(100, 116, 139)',
            marginBottom: '2rem'
          }}>
            NF Pastelaria
          </p>

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div>
              <label style={{
                display: 'block',
                fontSize: '0.875rem',
                fontWeight: '600',
                marginBottom: '0.5rem',
                color: 'rgb(15, 23, 42)'
              }}>
                Senha de Administrador
              </label>
              <input
                type="password"
                placeholder="Digite a senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isLoading}
                autoFocus
                style={{
                  width: '100%',
                  padding: '0.5rem 1rem',
                  border: '2px solid rgb(209, 213, 219)',
                  borderRadius: '0.5rem',
                  fontSize: '1rem',
                  outline: 'none',
                  transition: 'border-color 0.2s'
                }}
                onFocus={(e) => e.target.style.borderColor = 'rgb(220, 38, 38)'}
              />
            </div>

            {error && (
              <div style={{
                background: 'rgb(254, 226, 226)',
                border: '1px solid rgb(252, 165, 165)',
                color: 'rgb(220, 38, 38)',
                padding: '0.75rem',
                borderRadius: '0.5rem',
                fontSize: '0.875rem'
              }}>
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              style={{
                width: '100%',
                background: isLoading ? 'rgba(220, 38, 38, 0.5)' : 'rgb(220, 38, 38)',
                color: 'white',
                fontWeight: 'bold',
                height: '2.75rem',
                borderRadius: '0.5rem',
                border: 'none',
                cursor: isLoading ? 'not-allowed' : 'pointer',
                transition: 'background 0.2s',
                fontSize: '1rem'
              }}
              onMouseOver={(e) => !isLoading && (e.currentTarget.style.background = 'rgb(185, 28, 28)')}
              onMouseOut={(e) => !isLoading && (e.currentTarget.style.background = 'rgb(220, 38, 38)')}
            >
              {isLoading ? 'Entrando...' : 'Entrar'}
            </button>
          </form>

          <p style={{
            textAlign: 'center',
            fontSize: '0.75rem',
            color: 'rgb(100, 116, 139)',
            marginTop: '1rem'
          }}>
            Senha padrão: admin123
          </p>
        </div>
      </div>
    </div>
  )
}

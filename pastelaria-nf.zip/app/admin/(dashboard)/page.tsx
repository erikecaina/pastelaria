'use client'

import { useAdminData } from '@/hooks/use-admin-data'
import { Card } from '@/components/ui/card'
import { Package, ShoppingCart, DollarSign, TrendingUp } from 'lucide-react'

export default function AdminDashboard() {
  const { products, orders } = useAdminData()

  const totalRevenue = orders.reduce((sum, order) => sum + (order.total || 0), 0)
  const totalOrders = orders.length
  const totalProducts = products.length
  const activeProducts = products.filter((p) => p.active).length

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-5xl font-black text-foreground mb-3">Dashboard</h1>
        <p className="text-lg text-muted-foreground">
          Bem-vindo ao painel de administração da NF Pastelaria
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total de Produtos */}
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-bold text-blue-600 mb-2">
                Total de Produtos
              </p>
              <p className="text-4xl font-black text-blue-700">{totalProducts}</p>
              <p className="text-xs text-blue-600 mt-2 font-semibold">
                {activeProducts} ativos
              </p>
            </div>
            <div className="bg-blue-200 p-4 rounded-xl">
              <Package className="w-8 h-8 text-blue-700" />
            </div>
          </div>
        </div>

        {/* Pedidos Recebidos */}
        <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-2 border-yellow-200 rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-bold text-yellow-700 mb-2">
                Pedidos Recebidos
              </p>
              <p className="text-4xl font-black text-yellow-700">{totalOrders}</p>
              <p className="text-xs text-yellow-700 mt-2 font-semibold">
                todos os tempos
              </p>
            </div>
            <div className="bg-yellow-200 p-4 rounded-xl">
              <ShoppingCart className="w-8 h-8 text-yellow-700" />
            </div>
          </div>
        </div>

        {/* Receita Total */}
        <div className="bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200 rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-bold text-green-700 mb-2">
                Receita Total
              </p>
              <p className="text-4xl font-black text-green-700">
                R$ {(totalRevenue || 0).toFixed(2)}
              </p>
              <p className="text-xs text-green-700 mt-2 font-semibold">
                faturamento geral
              </p>
            </div>
            <div className="bg-green-200 p-4 rounded-xl">
              <DollarSign className="w-8 h-8 text-green-700" />
            </div>
          </div>
        </div>

        {/* Ticket Médio */}
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-200 rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-bold text-purple-700 mb-2">
                Ticket Médio
              </p>
              <p className="text-4xl font-black text-purple-700">
                {totalOrders > 0
                  ? `R$ ${((totalRevenue || 0) / totalOrders).toFixed(2)}`
                  : 'R$ 0,00'}
              </p>
              <p className="text-xs text-purple-700 mt-2 font-semibold">
                valor médio
              </p>
            </div>
            <div className="bg-purple-200 p-4 rounded-xl">
              <TrendingUp className="w-8 h-8 text-purple-700" />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Produtos Mais Vendidos */}
        <Card className="p-8 bg-white border-2 border-gray-200 rounded-2xl shadow-lg">
          <h3 className="font-black text-2xl text-foreground mb-6">
            Produtos Mais Vendidos
          </h3>
          {totalProducts === 0 ? (
            <p className="text-muted-foreground">Nenhum produto cadastrado</p>
          ) : (
            <div className="space-y-3">
              {products.slice(0, 5).map((product) => (
                <div
                  key={product.id}
                  className="flex justify-between items-center py-3 px-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <span className="text-foreground font-bold">
                    {product.name}
                  </span>
                  <span className="text-purple-600 font-black text-lg">
                    R$ {(product.price || 0).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Últimos Pedidos */}
        <Card className="p-8 bg-white border-2 border-gray-200 rounded-2xl shadow-lg">
          <h3 className="font-black text-2xl text-foreground mb-6">
            Últimos Pedidos
          </h3>
          {totalOrders === 0 ? (
            <p className="text-muted-foreground">Nenhum pedido recebido</p>
          ) : (
            <div className="space-y-3">
              {orders.slice(-5).map((order, idx) => (
                <div
                  key={idx}
                  className="flex justify-between items-center py-3 px-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <span className="text-foreground font-bold">
                    {order.customerName}
                  </span>
                  <span className="text-green-600 font-black text-lg">
                    R$ {(order.total || 0).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}

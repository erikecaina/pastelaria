'use client'

import { useAdminData } from '@/hooks/use-admin-data'
import { Button } from '@/components/ui/button'
import { Edit2, Trash2, Plus, Eye, EyeOff } from 'lucide-react'
import { useState } from 'react'
import { ProductEditModal } from '@/components/admin/product-edit-modal'
import { Product } from '@/lib/types'

export default function ProdutosPage() {
  const { products, updateProduct, deleteProduct, addProduct } = useAdminData()
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isAddingNew, setIsAddingNew] = useState(false)

  const handleEdit = (product: Product) => {
    setSelectedProduct(product)
    setIsAddingNew(false)
    setIsModalOpen(true)
  }

  const handleNew = () => {
    setSelectedProduct(null)
    setIsAddingNew(true)
    setIsModalOpen(true)
  }

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja deletar este produto?')) {
      deleteProduct(id)
    }
  }

  const handleToggleActive = (product: Product) => {
    updateProduct(product.id, { active: !product.active })
  }

  const handleSave = (productData: Partial<Product>) => {
    if (isAddingNew) {
      const newProduct: Product = {
        id: `product-${Date.now()}`,
        name: productData.name || '',
        description: productData.description || '',
        price: productData.price || 0,
        category: productData.category || 'salgados',
        active: true,
        image: productData.image,
      }
      addProduct(newProduct)
    } else if (selectedProduct) {
      updateProduct(selectedProduct.id, productData)
    }
    setIsModalOpen(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Produtos</h1>
          <p className="text-muted-foreground mt-1">
            Gerencie todos os produtos da loja
          </p>
        </div>
        <Button
          onClick={handleNew}
          className="bg-primary hover:bg-primary/90"
        >
          <Plus className="w-4 h-4 mr-2" />
          Novo Produto
        </Button>
      </div>

      <div className="bg-white rounded-lg border border-border overflow-hidden">
        <table className="w-full">
          <thead className="bg-muted border-b border-border">
            <tr>
              <th className="text-left px-6 py-4 font-semibold text-foreground">
                Nome
              </th>
              <th className="text-left px-6 py-4 font-semibold text-foreground">
                Categoria
              </th>
              <th className="text-left px-6 py-4 font-semibold text-foreground">
                Preço
              </th>
              <th className="text-left px-6 py-4 font-semibold text-foreground">
                Status
              </th>
              <th className="text-right px-6 py-4 font-semibold text-foreground">
                Ações
              </th>
            </tr>
          </thead>
          <tbody>
            {products.length === 0 ? (
              <tr>
                <td colSpan={5} className="text-center py-8 text-muted-foreground">
                  Nenhum produto cadastrado
                </td>
              </tr>
            ) : (
              products.map((product) => (
                <tr key={product.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                  <td className="px-6 py-4">
                    <div>
                      <p className="font-semibold text-foreground">
                        {product.name}
                      </p>
                      <p className="text-sm text-muted-foreground line-clamp-1">
                        {product.description}
                      </p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm capitalize text-muted-foreground">
                      {product.category === 'salgados' && 'Salgado'}
                      {product.category === 'doces' && 'Doce'}
                      {product.category === 'bebidas' && 'Bebida'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <p className="font-semibold text-primary">
                      R$ {(product.price || 0).toFixed(2)}
                    </p>
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => handleToggleActive(product)}
                      className={`flex items-center gap-2 text-sm font-semibold transition-colors ${
                        product.active
                          ? 'text-green-600 hover:text-green-700'
                          : 'text-gray-400 hover:text-gray-500'
                      }`}
                    >
                      {product.active ? (
                        <>
                          <Eye className="w-4 h-4" />
                          Ativo
                        </>
                      ) : (
                        <>
                          <EyeOff className="w-4 h-4" />
                          Inativo
                        </>
                      )}
                    </button>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(product)}
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDelete(product.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <ProductEditModal
        product={selectedProduct}
        isOpen={isModalOpen}
        isNew={isAddingNew}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSave}
      />
    </div>
  )
}

'use client'

import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { PrinterStatus } from '@/components/admin/printer-status'
import { OrdersList } from '@/components/admin/orders-list'
import { useOrderNotifications } from '@/hooks/use-order-notifications'
import { useOrdersSimple } from '@/hooks/use-orders-simple'
import { usePrinter } from '@/contexts/printer-context'

export default function PedidosPage() {
  const [soundEnabled, setSoundEnabled] = useState(true)
  const { orders, updateOrderStatus, addOrder } = useOrdersSimple()
  const { isConnected, printOrder } = usePrinter()
  const [autoprint, setAutoprint] = useState(true)
  const [lastPrintedOrderId, setLastPrintedOrderId] = useState<string | null>(null)

  // Hook para monitorar novos pedidos com notificação sonora
  useOrderNotifications(soundEnabled)



  const handlePrint = async (orderId: string) => {
    const order = orders.find((o) => o.id === orderId)
    
    if (!order) {
      alert('Pedido não encontrado')
      return
    }

    try {
      const success = await printOrder(order)
      
      if (success) {
        updateOrderStatus(orderId, 'impresso')
        alert('Pedido impresso com sucesso!')
      } else {
        alert('Erro ao imprimir. Verifique a conexão da impressora e reconecte.')
      }
    } catch (error) {
      alert('Erro ao imprimir: ' + (error instanceof Error ? error.message : 'Erro desconhecido'))
    }
  }

  const handleStatusChange = (orderId: string, status: 'pendente' | 'impresso' | 'entregue') => {
    updateOrderStatus(orderId, status)
  }

  const toggleSound = () => {
    setSoundEnabled(!soundEnabled)
  }

  // Função para testar com um novo pedido de exemplo
  const testNewOrder = () => {
    addOrder({
      customerName: `Cliente Teste ${Date.now()}`,
      phone: '5583996568140',
      address: 'Rua de Teste, 123 - Centro',
      items: [
        { productName: 'Pastel de Carne', quantity: 2, price: 8.0 },
        { productName: 'Pastel de Queijo', quantity: 1, price: 7.0 },
      ],
      total: 23.0,
    })
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-5xl font-black text-foreground mb-3">Pedidos</h1>
        <p className="text-lg text-muted-foreground">
          Gerencia e imprime os pedidos recebidos
        </p>
        <div className="mt-3 p-3 bg-blue-50 border-l-4 border-blue-500 rounded">
          <p className="text-blue-900 text-sm font-bold mb-1">🔵 PARA CONECTAR A IMPRESSORA:</p>
          <ul className="text-blue-800 text-xs space-y-1 ml-2">
            <li>✓ Use <strong>Chrome, Edge ou Opera</strong> (não funciona em Firefox/Safari)</li>
            <li>✓ Impressora <strong>MP-58C7 ligada e em modo pareamento</strong></li>
            <li>✓ Impressora já pareada no <strong>Bluetooth do seu computador</strong></li>
          </ul>
          <p className="text-blue-700 text-xs mt-2 italic">
            Veja BLUETOOTH_PRINTER_GUIDE.md para instruções completas
          </p>
        </div>
      </div>

      <PrinterStatus soundEnabled={soundEnabled} onToggleSound={toggleSound} />

      <div className="flex flex-wrap gap-3">
        <button
          onClick={testNewOrder}
          className="px-4 py-2 bg-purple-600 text-white rounded-lg font-bold hover:bg-purple-700 transition-colors"
        >
          + Simular Novo Pedido
        </button>
        
        <button
          onClick={() => setAutoprint(!autoprint)}
          className={`px-4 py-2 rounded-lg font-bold transition-colors ${
            autoprint
              ? 'bg-green-600 text-white hover:bg-green-700'
              : 'bg-gray-300 text-gray-700 hover:bg-gray-400'
          }`}
        >
          {autoprint ? '✓ Impressão Automática' : 'Impressão Manual'}
        </button>

        {!isConnected && (
          <button
            onClick={() => window.location.href = window.location.href}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-bold transition-colors"
            title="Reconecte a impressora pressionando F5 ou clicando aqui"
          >
            ⚠ Reconectar Impressora
          </button>
        )}
      </div>

      <OrdersList
        orders={orders}
        onPrint={handlePrint}
        onStatusChange={handleStatusChange}
      />

      {orders.length > 0 && (
        <Card className="p-6 bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-200 rounded-2xl">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-black text-foreground mb-1">Resumo de Pedidos</h3>
              <p className="text-sm text-muted-foreground">
                Total: {orders.length} pedidos | Pendentes:{' '}
                {orders.filter((o) => o.status === 'pendente').length} | Entregues:{' '}
                {orders.filter((o) => o.status === 'entregue').length}
              </p>
            </div>
            <div className="text-right">
              <p className="font-black text-3xl text-purple-600">
                R${' '}
                {orders
                  .reduce((sum, order) => sum + (order.total || 0), 0)
                  .toFixed(2)}
              </p>
              <p className="text-xs text-muted-foreground">Faturamento total</p>
            </div>
          </div>
        </Card>
      )}
    </div>
  )
}

'use client'

import { useAdminData } from '@/hooks/use-admin-data'
import { Card } from '@/components/ui/card'
import { DollarSign, ShoppingCart, TrendingUp } from 'lucide-react'

export default function CaixaPage() {
  const { orders } = useAdminData()

  const totalRevenue = orders.reduce((sum, order) => sum + (order.total || 0), 0)
  const totalOrders = orders.length
  const averageTicket = totalOrders > 0 ? totalRevenue / totalOrders : 0
  const cashAmount = orders.filter((o) => o.paymentMethod === 'dinheiro').reduce((sum, order) => sum + (order.total || 0), 0)
  const pixAmount = orders.filter((o) => o.paymentMethod === 'pix').reduce((sum, order) => sum + (order.total || 0), 0)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Caixa</h1>
        <p className="text-muted-foreground mt-1">
          Acompanhamento financeiro da loja
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6 bg-white border border-border">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-semibold mb-2">
                Receita Total
              </p>
              <p className="text-4xl font-bold text-primary">
                R$ {(totalRevenue || 0).toFixed(2)}
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                de todos os tempos
              </p>
            </div>
            <div className="bg-primary/10 p-3 rounded-lg">
              <DollarSign className="w-6 h-6 text-primary" />
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-white border border-border">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-semibold mb-2">
                Total de Pedidos
              </p>
              <p className="text-4xl font-bold text-secondary">{totalOrders}</p>
              <p className="text-xs text-muted-foreground mt-2">
                pedidos recebidos
              </p>
            </div>
            <div className="bg-secondary/10 p-3 rounded-lg">
              <ShoppingCart className="w-6 h-6 text-secondary" />
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-white border border-border">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-semibold mb-2">
                Ticket Médio
              </p>
              <p className="text-4xl font-bold text-primary">
                R$ {(averageTicket || 0).toFixed(2)}
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                valor médio por pedido
              </p>
            </div>
            <div className="bg-primary/10 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-primary" />
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6 bg-white border border-border">
        <h3 className="font-bold text-lg text-foreground mb-4">
          Resumo por Forma de Pagamento
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
            <div>
              <p className="text-sm text-muted-foreground">Dinheiro</p>
              <p className="text-2xl font-bold text-green-600">R$ {(cashAmount || 0).toFixed(2)}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Pedidos</p>
              <p className="text-lg font-bold">{orders.filter((o) => o.paymentMethod === 'dinheiro').length}</p>
            </div>
          </div>
          <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div>
              <p className="text-sm text-muted-foreground">PIX</p>
              <p className="text-2xl font-bold text-blue-600">R$ {(pixAmount || 0).toFixed(2)}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Pedidos</p>
              <p className="text-lg font-bold">{orders.filter((o) => o.paymentMethod === 'pix').length}</p>
            </div>
          </div>
          <div className="flex items-center justify-between p-4 bg-primary/10 rounded-lg border-2 border-primary">
            <div>
              <p className="text-sm font-semibold text-foreground">Total</p>
              <p className="text-2xl font-bold text-primary">R$ {(totalRevenue || 0).toFixed(2)}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Total de Pedidos</p>
              <p className="text-lg font-bold">{totalOrders}</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}


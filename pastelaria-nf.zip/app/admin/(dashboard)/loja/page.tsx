'use client'

import { useStore } from '@/contexts/store-context'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useState, useEffect } from 'react'
import { Check } from 'lucide-react'

function LojaPageContent() {
  const { storeConfig, updateStoreConfig } = useStore()
  const [formData, setFormData] = useState(storeConfig)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    setFormData(storeConfig)
  }, [storeConfig])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    if (name.includes('deliveryFee') || name.includes('minOrderValue')) {
      setFormData(prev => ({
        ...prev,
        [name]: parseFloat(value) || 0
      }))
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }))
    }
  }

  const handleSave = () => {
    updateStoreConfig(formData)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Configurações da Loja</h1>
        <p className="text-gray-500 mt-2">Atualize as informações da pastelaria aqui. Qualquer mudança aparecerá automaticamente no site.</p>
      </div>

      {saved && (
        <div className="flex items-center gap-2 p-4 bg-green-50 border border-green-200 rounded-lg">
          <Check size={20} className="text-green-600" />
          <span className="text-green-700 font-medium">Configurações salvas com sucesso!</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Informações Básicas */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Informações Básicas</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Nome da Loja
              </label>
              <Input
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Slogan
              </label>
              <Input
                name="slogan"
                value={formData.slogan}
                onChange={handleChange}
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Status da Loja
              </label>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setFormData(prev => ({ ...prev, isOpen: true }))}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    formData.isOpen 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  Aberta
                </button>
                <button
                  onClick={() => setFormData(prev => ({ ...prev, isOpen: false }))}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    !formData.isOpen 
                      ? 'bg-red-500 text-white' 
                      : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  Fechada
                </button>
              </div>
            </div>
          </div>
        </Card>

        {/* Contato e Endereço */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Contato e Endereço</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                WhatsApp (com código de área)
              </label>
              <Input
                name="whatsapp"
                value={formData.whatsapp}
                onChange={handleChange}
                placeholder="83 98743-3682"
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Endereço
              </label>
              <Input
                name="address"
                value={formData.address || ''}
                onChange={handleChange}
                placeholder="Rua, número"
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Bairro
              </label>
              <Input
                name="neighborhood"
                value={formData.neighborhood || ''}
                onChange={handleChange}
                className="w-full"
              />
            </div>
          </div>
        </Card>

        {/* Configurações de Entrega */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Entrega</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Taxa de Entrega (R$)
              </label>
              <Input
                name="deliveryFee"
                type="number"
                step="0.01"
                value={formData.deliveryFee}
                onChange={handleChange}
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Valor Mínimo do Pedido (R$)
              </label>
              <Input
                name="minOrderValue"
                type="number"
                step="0.01"
                value={formData.minOrderValue}
                onChange={handleChange}
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Tempo de Entrega
              </label>
              <Input
                name="deliveryTime"
                value={formData.deliveryTime || '30-45 min'}
                onChange={handleChange}
                placeholder="ex: 30-45 min"
                className="w-full"
              />
            </div>
          </div>
        </Card>

        {/* Horário de Funcionamento */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-foreground mb-4">Horário de Funcionamento</h2>
          <div className="space-y-3 text-sm">
            {Object.entries({
              monday: 'Segunda',
              tuesday: 'Terça',
              wednesday: 'Quarta',
              thursday: 'Quinta',
              friday: 'Sexta',
              saturday: 'Sábado',
              sunday: 'Domingo',
            }).map(([key, label]) => (
              <div key={key} className="flex items-center gap-2">
                <span className="w-20 text-foreground font-medium">{label}:</span>
                <Input
                  value={formData.openingHours?.[key as keyof typeof formData.openingHours] || ''}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    openingHours: {
                      ...prev.openingHours,
                      [key]: e.target.value
                    }
                  }))}
                  placeholder="08:00 - 22:00"
                  className="flex-1 h-8"
                />
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          className="bg-red-600 hover:bg-red-700 text-white px-8 py-2 rounded-lg font-semibold"
        >
          Salvar Configurações
        </Button>
      </div>
    </div>
  )
}

export default function LojaPage() {
  return <LojaPageContent />
}

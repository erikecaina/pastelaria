'use client'

import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Plus, Edit2, Trash2 } from 'lucide-react'
import { useState } from 'react'

const defaultCategories = [
  { id: 'salgados', name: 'Salgados', description: 'Pastéis salgados variados' },
  { id: 'doces', name: 'Doces', description: 'Pastéis doces' },
  { id: 'bebidas', name: 'Bebidas', description: 'Bebidas e sucos' },
]

export default function CategoriasPage() {
  const [categories] = useState(defaultCategories)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Categorias</h1>
          <p className="text-muted-foreground mt-1">
            Gerencie as categorias de produtos
          </p>
        </div>
        <Button className="bg-primary hover:bg-primary/90">
          <Plus className="w-4 h-4 mr-2" />
          Nova Categoria
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map((category) => (
          <Card key={category.id} className="p-6 border border-border hover:shadow-lg transition-shadow">
            <h3 className="font-bold text-lg text-foreground mb-2">
              {category.name}
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              {category.description}
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex-1 gap-2">
                <Edit2 className="w-4 h-4" />
                Editar
              </Button>
              <Button variant="outline" size="sm" className="flex-1 text-red-600 hover:bg-red-50 gap-2">
                <Trash2 className="w-4 h-4" />
                Remover
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}


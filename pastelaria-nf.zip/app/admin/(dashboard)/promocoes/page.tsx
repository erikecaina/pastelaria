'use client'

import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Plus, Edit2, Trash2, X } from 'lucide-react'
import { useState, useEffect } from 'react'

interface Promotion {
  id: string
  title: string
  description: string
  subtitle?: string
  discount?: number
  bgColor?: string
  bgColorEnd?: string
  icon?: string
  startDate: string
  endDate: string
  active: boolean
}

export default function PromocoesPage() {
  const [promotions, setPromotions] = useState<Promotion[]>([])
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState<Promotion>({
    id: '',
    title: '',
    description: '',
    subtitle: '',
    discount: 0,
    bgColor: '#FF6B35',
    bgColorEnd: '#FF8C5A',
    icon: '🎉',
    startDate: '',
    endDate: '',
    active: false,
  })

  useEffect(() => {
    loadPromotions()
  }, [])

  const loadPromotions = () => {
    try {
      const stored = localStorage.getItem('nf-pastelaria-promotions')
      if (stored) {
        setPromotions(JSON.parse(stored))
      }
    } catch (e) {
      console.error('Erro ao carregar promoções:', e)
    }
  }

  const savePromotions = (newPromotions: Promotion[]) => {
    localStorage.setItem('nf-pastelaria-promotions', JSON.stringify(newPromotions))
    setPromotions(newPromotions)
  }

  const handleAddPromo = () => {
    setEditingId(null)
    setFormData({
      id: '',
      title: '',
      description: '',
      subtitle: '',
      discount: 0,
      bgColor: '#FF6B35',
      bgColorEnd: '#FF8C5A',
      icon: '🎉',
      startDate: '',
      endDate: '',
      active: false,
    })
    setShowForm(true)
  }

  const handleEditPromo = (promo: Promotion) => {
    setEditingId(promo.id)
    setFormData(promo)
    setShowForm(true)
  }

  const handleSavePromo = () => {
    if (!formData.title || !formData.description) {
      alert('Preencha todos os campos obrigatórios')
      return
    }

    let newPromotions: Promotion[]

    if (editingId) {
      newPromotions = promotions.map((p) =>
        p.id === editingId ? { ...formData, id: editingId } : p
      )
    } else {
      newPromotions = [
        ...promotions,
        { ...formData, id: Date.now().toString() },
      ]
    }

    savePromotions(newPromotions)
    setShowForm(false)
  }

  const handleDeletePromo = (id: string) => {
    if (confirm('Tem certeza que deseja remover esta promoção?')) {
      const newPromotions = promotions.filter((p) => p.id !== id)
      savePromotions(newPromotions)
    }
  }

  const handleToggleActive = (id: string) => {
    const newPromotions = promotions.map((p) =>
      p.id === id ? { ...p, active: !p.active } : p
    )
    savePromotions(newPromotions)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Promoções</h1>
          <p className="text-muted-foreground mt-1">
            Crie e gerencie promoções especiais que aparecem na página inicial
          </p>
        </div>
        <Button
          onClick={handleAddPromo}
          className="bg-primary hover:bg-primary/90"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nova Promoção
        </Button>
      </div>

      {showForm && (
        <Card className="p-6 border-2 border-primary/20">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold">
              {editingId ? 'Editar Promoção' : 'Nova Promoção'}
            </h2>
            <button
              onClick={() => setShowForm(false)}
              className="text-muted-foreground hover:text-foreground"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold mb-2">
                Título *
              </label>
              <Input
                value={formData.title}
                onChange={(e) =>
                  setFormData({ ...formData, title: e.target.value })
                }
                placeholder="Ex: Promoção Relâmpago"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2">
                Descrição *
              </label>
              <Input
                value={formData.description}
                onChange={(e) =>
                  setFormData({ ...formData, description: e.target.value })
                }
                placeholder="Ex: 20% OFF em todos os pastéis"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2">
                Subtítulo
              </label>
              <Input
                value={formData.subtitle || ''}
                onChange={(e) =>
                  setFormData({ ...formData, subtitle: e.target.value })
                }
                placeholder="Ex: Válido apenas hoje"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold mb-2">
                  Cor de Fundo
                </label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={formData.bgColor || '#FF6B35'}
                    onChange={(e) =>
                      setFormData({ ...formData, bgColor: e.target.value })
                    }
                    className="w-12 h-10 rounded cursor-pointer"
                  />
                  <Input
                    value={formData.bgColor || '#FF6B35'}
                    onChange={(e) =>
                      setFormData({ ...formData, bgColor: e.target.value })
                    }
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">
                  Cor de Fundo (Gradiente)
                </label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={formData.bgColorEnd || '#FF8C5A'}
                    onChange={(e) =>
                      setFormData({ ...formData, bgColorEnd: e.target.value })
                    }
                    className="w-12 h-10 rounded cursor-pointer"
                  />
                  <Input
                    value={formData.bgColorEnd || '#FF8C5A'}
                    onChange={(e) =>
                      setFormData({ ...formData, bgColorEnd: e.target.value })
                    }
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold mb-2">
                  Data de Início
                </label>
                <Input
                  type="date"
                  value={formData.startDate}
                  onChange={(e) =>
                    setFormData({ ...formData, startDate: e.target.value })
                  }
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">
                  Data de Término
                </label>
                <Input
                  type="date"
                  value={formData.endDate}
                  onChange={(e) =>
                    setFormData({ ...formData, endDate: e.target.value })
                  }
                />
              </div>
            </div>

            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="active"
                checked={formData.active}
                onChange={(e) =>
                  setFormData({ ...formData, active: e.target.checked })
                }
                className="w-4 h-4 cursor-pointer"
              />
              <label htmlFor="active" className="text-sm font-semibold">
                Ativar promoção
              </label>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                onClick={handleSavePromo}
                className="bg-primary hover:bg-primary/90 flex-1"
              >
                Salvar Promoção
              </Button>
              <Button
                onClick={() => setShowForm(false)}
                variant="outline"
                className="flex-1"
              >
                Cancelar
              </Button>
            </div>
          </div>
        </Card>
      )}

      {promotions.length === 0 && !showForm ? (
        <Card className="p-12 text-center">
          <p className="text-muted-foreground text-lg">
            Nenhuma promoção cadastrada
          </p>
          <p className="text-muted-foreground text-sm mt-2">
            Crie uma promoção para atrair mais clientes
          </p>
        </Card>
      ) : (
        <div className="space-y-4">
          {promotions.map((promo) => (
            <Card key={promo.id} className="p-6 border border-border">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="font-bold text-lg text-foreground">
                    {promo.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {promo.description}
                  </p>
                  {promo.subtitle && (
                    <p className="text-xs text-muted-foreground mt-1">
                      {promo.subtitle}
                    </p>
                  )}
                </div>
                <button
                  onClick={() => handleToggleActive(promo.id)}
                  className={`px-3 py-1 rounded-full text-sm font-semibold transition-colors ${
                    promo.active
                      ? 'bg-green-100 text-green-700 hover:bg-green-200'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {promo.active ? 'Ativa' : 'Inativa'}
                </button>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  <p>
                    Período:{' '}
                    <span className="font-bold">
                      {promo.startDate} a {promo.endDate}
                    </span>
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => handleEditPromo(promo)}
                    variant="outline"
                    size="sm"
                    className="gap-2"
                  >
                    <Edit2 className="w-4 h-4" />
                    Editar
                  </Button>
                  <Button
                    onClick={() => handleDeletePromo(promo.id)}
                    variant="outline"
                    size="sm"
                    className="text-red-600 hover:bg-red-50 gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    Remover
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

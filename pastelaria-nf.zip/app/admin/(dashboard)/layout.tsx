'use client'

import { AdminProtected } from '@/components/admin/admin-protected'
import { AdminLayoutContent } from '@/components/admin/admin-layout-content'

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <AdminProtected>
      <AdminLayoutContent>
        {children}
      </AdminLayoutContent>
    </AdminProtected>
  )
}

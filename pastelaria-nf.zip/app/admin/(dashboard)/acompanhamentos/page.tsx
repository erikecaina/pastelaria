'use client'

export default function AcompanhamentosPage() {
  const acompanhamentos = [
    { categoria: 'Frutas', itens: ['Banana', 'Morango'] },
    { categoria: 'Complementos', itens: ['Granola', 'Leite em pó', 'Amendoim'] },
    { categoria: 'Caldas', itens: ['Chocolate', 'Caramelo', 'Morango'] },
    { categoria: 'Cremes', itens: ['Nutella', 'Doce de leite', 'Sorvete de baunilha'] },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Acompanhamentos</h1>
        <p className="text-muted-foreground mt-1">
          Gerencie os acompanhamentos disponíveis
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {acompanhamentos.map((grupo) => (
          <div key={grupo.categoria} className="bg-white rounded-lg border border-border p-6">
            <h3 className="font-bold text-lg text-foreground mb-4">
              {grupo.categoria}
            </h3>
            <ul className="space-y-2">
              {grupo.itens.map((item) => (
                <li
                  key={item}
                  className="flex items-center justify-between p-3 bg-muted rounded-lg"
                >
                  <span className="text-foreground">{item}</span>
                  <span className="text-sm text-muted-foreground">Grátis</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  )
}

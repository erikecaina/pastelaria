'use client'

import { AdminAuthProvider } from '@/hooks/use-admin-auth'
import { OrdersProvider } from '@/contexts/orders-context'
import { ProductsProvider } from '@/contexts/products-context'
import { PrinterProvider } from '@/contexts/printer-context'

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <AdminAuthProvider>
      <PrinterProvider>
        <ProductsProvider>
          <OrdersProvider>
            {children}
          </OrdersProvider>
        </ProductsProvider>
      </PrinterProvider>
    </AdminAuthProvider>
  )
}



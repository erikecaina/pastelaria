'use client'

import { useCart } from '@/hooks/use-cart'
import { CartSummary } from '@/components/storefront/cart-summary'
import { CheckoutForm } from '@/components/storefront/checkout-form'
import { PaymentSelector } from '@/components/storefront/payment-selector'
import { useWhatsAppMessage } from '@/hooks/use-whatsapp-message'
import { storeInfo } from '@/lib/store-data'
import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ChevronLeft } from 'lucide-react'

type CheckoutStep = 'cart' | 'checkout' | 'payment'

interface CheckoutData {
  name: string
  street: string
  number: string
  neighborhood: string
  complement?: string
}

export default function CartPage() {
  const { items, subtotal, total, clearCart } = useCart()
  const { generateMessage, generateWhatsAppLink } = useWhatsAppMessage()
  const [currentStep, setCurrentStep] = useState<CheckoutStep>('cart')
  const [checkoutData, setCheckoutData] = useState<CheckoutData | null>(null)

  if (items.length === 0 && currentStep === 'cart') {
    return (
      <main className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-2xl mx-auto px-4">
          <Link href="/">
            <Button variant="outline" className="mb-6">
              <ChevronLeft className="w-4 h-4 mr-2" />
              Voltar ao Menu
            </Button>
          </Link>

          <div className="bg-white rounded-lg p-8 text-center shadow">
            <h1 className="text-2xl font-bold text-foreground mb-4">Seu carrinho está vazio</h1>
            <p className="text-muted-foreground mb-6">
              Adicione alguns pastéis deliciosos para começar
            </p>
            <Link href="/">
              <Button className="bg-primary hover:bg-primary/90 text-white">
                Voltar ao Menu
              </Button>
            </Link>
          </div>
        </div>
      </main>
    )
  }

  const handleCheckoutNext = (data: CheckoutData) => {
    setCheckoutData(data)
    setCurrentStep('payment')
  }

  const handlePaymentSelect = (method: string, change?: number) => {
    if (!checkoutData) return

    const address = {
      street: checkoutData.street,
      number: checkoutData.number,
      neighborhood: checkoutData.neighborhood,
      complement: checkoutData.complement,
    }

    const message = generateMessage(
      items,
      subtotal,
      2.0, // deliveryFee
      total,
      checkoutData.name,
      address,
      method,
      change
    )

    const whatsappLink = generateWhatsAppLink(storeInfo.whatsapp, message)
    window.open(whatsappLink, '_blank')

    // Clear cart after sending
    setTimeout(() => {
      clearCart()
      setCurrentStep('cart')
      setCheckoutData(null)
    }, 1000)
  }

  return (
    <main className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <Link href="/">
          <Button variant="outline" className="mb-6">
            <ChevronLeft className="w-4 h-4 mr-2" />
            Voltar ao Menu
          </Button>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {currentStep === 'cart' && (
              <div className="bg-white rounded-lg p-6 shadow">
                <h1 className="text-3xl font-black text-foreground mb-6">
                  Seu Pedido
                </h1>
                <CartSummary
                  items={items}
                  onCheckout={() => setCurrentStep('checkout')}
                />
              </div>
            )}

            {currentStep === 'checkout' && (
              <div className="bg-white rounded-lg p-6 shadow">
                <h2 className="text-2xl font-black text-foreground mb-6">
                  Dados de Entrega
                </h2>
                <CheckoutForm onNext={handleCheckoutNext} />
              </div>
            )}

            {currentStep === 'payment' && (
              <div className="bg-white rounded-lg p-6 shadow">
                <h2 className="text-2xl font-black text-foreground mb-6">
                  Formas de Pagamento
                </h2>
                <PaymentSelector
                  total={total}
                  onSelectPayment={handlePaymentSelect}
                />
              </div>
            )}
          </div>

          {/* Summary Sidebar */}
          <div>
            <div className="bg-white rounded-lg p-6 shadow sticky top-8">
              <h3 className="font-black text-lg text-foreground mb-4">Resumo</h3>

              <div className="space-y-3 mb-6 pb-6 border-b">
                {items.map((item) => (
                  <div key={item.product.id} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">
                      {item.product.name} x{item.quantity}
                    </span>
                    <span className="font-bold">
                      R$ {(item.product.price * item.quantity).toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal:</span>
                  <span className="font-semibold">R$ {subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Taxa de entrega:</span>
                  <span className="font-semibold">R$ 2.00</span>
                </div>
                <div className="flex justify-between text-lg border-t pt-2 mt-2">
                  <span className="font-black text-foreground">Total:</span>
                  <span className="font-black text-primary">R$ {total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}

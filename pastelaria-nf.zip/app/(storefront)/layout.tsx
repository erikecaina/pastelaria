'use client'

import { CartProvider } from '@/hooks/use-cart'
import { ProductsProvider } from '@/contexts/products-context'
import { StoreProvider } from '@/contexts/store-context'

export default function StorefrontLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <StoreProvider>
      <ProductsProvider>
        <CartProvider>
          {children}
        </CartProvider>
      </ProductsProvider>
    </StoreProvider>
  )
}

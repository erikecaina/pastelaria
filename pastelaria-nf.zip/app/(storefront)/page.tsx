'use client'

import { useState } from 'react'
import Image from 'next/image'
import { HeroSection } from '@/components/storefront/hero-section'
import { CategoryFilter } from '@/components/storefront/category-filter'
import { ProductModal } from '@/components/storefront/product-modal'
import { useProducts } from '@/contexts/products-context'
import { Product } from '@/contexts/products-context'
import { useCart } from '@/hooks/use-cart'
import Link from 'next/link'
import { ShoppingCart } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState('todos')
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const { items } = useCart()
  const { products } = useProducts()

  const filteredProducts = selectedCategory === 'todos'
    ? products
    : products.filter(p => p.category === selectedCategory)

  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product)
    setIsModalOpen(true)
  }

  return (
    <main className="min-h-screen bg-background">
      <HeroSection />

      <CategoryFilter
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
      />

      <div className="max-w-7xl mx-auto">
        {filteredProducts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">
              Nenhum produto disponível nesta categoria
            </p>
          </div>
        ) : (
          <div className="space-y-0">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                onClick={() => handleProductSelect(product)}
                className="flex gap-4 md:gap-5 items-start p-4 md:p-6 bg-white border-b border-gray-200 hover:bg-gray-50/50 cursor-pointer transition-colors"
              >
                <div className="relative w-20 h-20 md:w-24 md:h-24 flex-shrink-0 rounded overflow-hidden bg-gray-100">
                  <Image
                    src={product.image || '/pastel-placeholder.png'}
                    alt={product.name}
                    fill
                    className="object-cover"
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <h3 className="font-black text-base md:text-lg text-foreground">
                    {product.name}
                  </h3>
                  <p className="text-xs md:text-sm text-muted-foreground mt-1 line-clamp-2">
                    {product.description}
                  </p>
                  <p className="text-xs text-muted-foreground mt-2 font-medium">
                    a partir de
                  </p>
                </div>

                <div className="flex-shrink-0 text-right whitespace-nowrap">
                  <p className="text-xl md:text-2xl font-black text-primary">
                    R$ {product.price.toFixed(2)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedProduct && (
        <ProductModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          product={selectedProduct}
        />
      )}

      {/* Floating Cart Button - Enhanced */}
      {items.length > 0 && (
        <div className="fixed bottom-6 right-6 z-40 animate-cart-bounce animate-cart-pulse">
          <Link href="/cart">
            <Button className="relative bg-gradient-to-br from-primary to-red-600 hover:from-primary/90 hover:to-red-700 text-white rounded-full p-6 shadow-2xl hover:shadow-3xl transition-all flex items-center gap-3 text-lg font-black">
              <ShoppingCart className="w-6 h-6" />
              <span className="text-sm font-black bg-yellow-300 text-primary rounded-full w-7 h-7 flex items-center justify-center absolute -top-2 -right-2 shadow-lg border-2 border-white">
                {items.length}
              </span>
              <span className="hidden sm:inline">Ver carrinho</span>
            </Button>
          </Link>
        </div>
      )}

      <footer className="bg-foreground text-background py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="font-semibold mb-2">NF Pastelaria</p>
          <p className="text-sm opacity-90">Pastéis frescos e deliciosos | Entrega rápida</p>
        </div>
      </footer>
    </main>
  )
}

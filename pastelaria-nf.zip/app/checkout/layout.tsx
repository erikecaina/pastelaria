'use client'

import { CartProvider } from '@/hooks/use-cart'
import { ProductsProvider } from '@/contexts/products-context'
import { StoreProvider } from '@/contexts/store-context'
import { OrdersProvider } from '@/contexts/orders-context'

export default function CheckoutLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <StoreProvider>
      <ProductsProvider>
        <OrdersProvider>
          <CartProvider>
            {children}
          </CartProvider>
        </OrdersProvider>
      </ProductsProvider>
    </StoreProvider>
  )
}

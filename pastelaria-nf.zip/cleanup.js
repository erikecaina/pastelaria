const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

async function cleanup() {
  try {
    // Deletar todos os pedidos de teste
    const { error } = await supabase
      .from('orders')
      .delete()
      .or("customer_name.ilike.%TESTE%,customer_name.ilike.%TEST%,customer_name.ilike.%CURL%,customer_name.ilike.%FINAL%,customer_name.ilike.%DEBUG%,customer_name.ilike.%NOVO CLIENTE%");

    if (error) {
      console.log('Erro ao deletar:', error);
    } else {
      console.log('✅ Pedidos de teste deletados com sucesso!');
    }
  } catch (error) {
    console.error('❌ Erro na limpeza:', error);
  }
}

cleanup();

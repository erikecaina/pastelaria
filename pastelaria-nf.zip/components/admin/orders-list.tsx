'use client'

import { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Printer, Check, Clock } from 'lucide-react'

interface OrderItem {
  productName: string
  quantity: number
  price: number
  observation?: string
}

interface Order {
  id: string
  customerName: string
  phone: string
  address: string
  items: OrderItem[]
  total: number
  created_at?: string
  status: 'pendente' | 'impresso' | 'entregue'
}

interface OrderListProps {
  orders: Order[]
  onPrint: (orderId: string) => void
  onStatusChange: (orderId: string, status: 'pendente' | 'impresso' | 'entregue') => void
}

export function OrdersList({
  orders,
  onPrint,
  onStatusChange,
}: OrderListProps) {
  const formatDate = (dateString?: string) => {
    if (!dateString) return 'Data não disponível'
    try {
      const d = new Date(dateString)
      return d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit',
      })
    } catch {
      return dateString
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'impresso':
        return 'bg-green-100 text-green-700'
      case 'entregue':
        return 'bg-blue-100 text-blue-700'
      case 'pendente':
        return 'bg-yellow-100 text-yellow-700'
      default:
        return 'bg-gray-100 text-gray-700'
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'impresso':
        return 'Impresso'
      case 'entregue':
        return 'Entregue'
      case 'pendente':
        return 'Pendente'
      default:
        return status
    }
  }

  if (orders.length === 0) {
    return (
      <Card className="p-12 text-center bg-white border-2 border-gray-200 rounded-2xl">
        <p className="text-muted-foreground text-lg">Nenhum pedido recebido ainda</p>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <h3 className="font-black text-2xl text-foreground mb-4">
        Pedidos Recentes ({orders.length})
      </h3>

      {orders.map((order) => (
        <Card
          key={order.id}
          className="p-6 bg-white border-2 border-gray-200 rounded-2xl shadow-md hover:shadow-lg transition-all"
        >
          <div className="flex justify-between items-start mb-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <h4 className="font-black text-lg text-foreground">
                  #{order.id}
                </h4>
                <Badge className={`${getStatusColor(order.status)} font-bold text-xs`}>
                  {getStatusLabel(order.status)}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{formatDate(order.created_at)}</p>
            </div>
            <div className="text-right">
              <p className="font-black text-2xl text-purple-600">
                R$ {(order.total || 0).toFixed(2)}
              </p>
              <p className="text-xs text-muted-foreground">
                {order.items.reduce((sum, item) => sum + item.quantity, 0)} itens
              </p>
            </div>
          </div>

          <div className="mb-4 p-4 bg-gray-50 rounded-xl">
            <p className="font-bold text-foreground mb-1">{order.customerName}</p>
            <p className="text-sm text-muted-foreground mb-3">{order.address}</p>

            <div className="space-y-2">
              {order.items.map((item, idx) => (
                <div key={idx} className="flex justify-between items-start text-sm">
                  <div className="flex-1">
                    <span className="text-foreground">
                      {item.quantity}x {item.productName}
                    </span>
                    {item.observation && (
                      <p className="text-xs text-muted-foreground italic mt-1">
                        Obs: {item.observation}
                      </p>
                    )}
                  </div>
                  <span className="text-muted-foreground ml-2">
                    R$ {((item.price || 0) * (item.quantity || 0)).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={() => onPrint(order.id)}
              className="flex-1 bg-purple-600 hover:bg-purple-700 text-white font-bold"
            >
              <Printer className="w-4 h-4 mr-2" />
              Imprimir
            </Button>

            <Select
              value={order.status}
              onValueChange={(value) =>
                onStatusChange(order.id, value as 'pendente' | 'impresso' | 'entregue')
              }
            >
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pendente">Pendente</SelectItem>
                <SelectItem value="impresso">Impresso</SelectItem>
                <SelectItem value="entregue">Entregue</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </Card>
      ))}
    </div>
  )
}

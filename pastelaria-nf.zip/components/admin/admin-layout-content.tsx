'use client'

import { Sidebar } from '@/components/admin/sidebar'
import { useAdminAuth } from '@/hooks/use-admin-auth'
import { Button } from '@/components/ui/button'
import { LogOut } from 'lucide-react'

export function AdminLayoutContent({ children }: { children: React.ReactNode }) {
  const { logout } = useAdminAuth()

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-gradient-to-r from-purple-600 to-purple-700 text-white border-b-4 border-purple-800 px-8 py-5 flex items-center justify-between shadow-lg">
          <h1 className="text-2xl font-black">Painel Admin - NF Pastelaria</h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={logout}
            className="text-white hover:bg-purple-700/50 font-bold"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sair
          </Button>
        </header>

        <main className="flex-1 overflow-auto">
          <div className="p-8">{children}</div>
        </main>
      </div>
    </div>
  )
}

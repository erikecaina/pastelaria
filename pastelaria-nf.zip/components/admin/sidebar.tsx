'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  Home,
  Package,
  Tag,
  ShoppingCart,
  DollarSign,
  Megaphone,
  Settings,
} from 'lucide-react'
import Image from 'next/image'

const menuItems = [
  { href: '/admin', icon: Home, label: 'Dashboard' },
  { href: '/admin/produtos', icon: Package, label: 'Produtos' },
  { href: '/admin/categorias', icon: Tag, label: 'Categorias' },
  { href: '/admin/pedidos', icon: ShoppingCart, label: 'Pedidos' },
  { href: '/admin/caixa', icon: DollarSign, label: 'Caixa' },
  { href: '/admin/promocoes', icon: Megaphone, label: 'Promoções' },
  { href: '/admin/loja', icon: Settings, label: 'Configurações' },
]

export function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="w-72 bg-gradient-to-b from-purple-700 to-purple-800 flex flex-col shadow-2xl">
      <div className="p-6 border-b-2 border-purple-600">
        <Link href="/admin" className="flex items-center gap-3">
          <div className="relative w-12 h-12 bg-white rounded-lg p-2 shadow-lg">
            <Image
              src="/logo.png"
              alt="NF Pastelaria"
              fill
              className="object-contain p-2"
            />
          </div>
          <div>
            <p className="font-black text-white text-base">
              NF Pastelaria
            </p>
            <p className="text-xs text-purple-200">Admin Panel</p>
          </div>
        </Link>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href

          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-all ${
                isActive
                  ? 'bg-white text-purple-700 shadow-lg'
                  : 'text-white hover:bg-purple-600/50'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-sm">{item.label}</span>
            </Link>
          )
        })}
      </nav>

      <div className="p-4 border-t-2 border-purple-600 text-xs text-purple-200">
        <p className="font-semibold">v1.0.0</p>
      </div>
    </aside>
  )
}

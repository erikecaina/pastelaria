'use client'

import { useAdminAuth } from '@/hooks/use-admin-auth'
import { redirect } from 'next/navigation'

export function AdminProtected({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAdminAuth()

  if (!isAuthenticated) {
    redirect('/admin/login')
  }

  return <>{children}</>
}

'use client'

import { Product } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { useState, useEffect, useRef } from 'react'
import { Upload, X, Loader2 } from 'lucide-react'

interface ProductEditModalProps {
  product: Product | null
  isOpen: boolean
  isNew: boolean
  onClose: () => void
  onSave: (product: Partial<Product>) => void
}

export function ProductEditModal({
  product,
  isOpen,
  isNew,
  onClose,
  onSave,
}: ProductEditModalProps) {
  const [formData, setFormData] = useState<Partial<Product>>({
    name: '',
    description: '',
    price: 0,
    category: 'salgados',
  })
  const [imagePreview, setImagePreview] = useState<string>('')
  const [uploading, setUploading] = useState(false)

  useEffect(() => {
    if (product) {
      setFormData(product)
      setImagePreview(product.image || '')
    } else if (isNew) {
      setFormData({
        name: '',
        description: '',
        price: 0,
        category: 'salgados',
      })
      setImagePreview('')
    }
  }, [product, isNew])

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        const base64String = reader.result as string
        setImagePreview(base64String)
        handleChange('image', base64String)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleRemoveImage = () => {
    setImagePreview('')
    handleChange('image', '')
  }

  const handleChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = () => {
    onSave(formData)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isNew ? 'Novo Produto' : 'Editar Produto'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div>
            <label className="block text-sm font-semibold mb-2 text-foreground">
              Imagem do Produto
            </label>
            <div className="flex flex-col gap-3">
              {imagePreview && (
                <div className="relative w-full rounded-lg overflow-hidden border-2 border-border bg-gray-100">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="w-full h-40 object-cover"
                  />
                  <button
                    onClick={handleRemoveImage}
                    className="absolute top-2 right-2 bg-red-500 hover:bg-red-600 text-white p-1 rounded-full transition-colors"
                    type="button"
                  >
                    <X size={18} />
                  </button>
                </div>
              )}
              <label className="flex items-center justify-center w-full px-4 py-2 border-2 border-dashed border-border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-2 text-foreground">
                  <Upload size={20} />
                  <span className="text-sm font-medium">
                    {imagePreview ? 'Trocar imagem' : 'Adicionar imagem'}
                  </span>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2 text-foreground">
              Nome *
            </label>
            <Input
              value={formData.name || ''}
              onChange={(e) => handleChange('name', e.target.value)}
              placeholder="Nome do produto"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2 text-foreground">
              Descrição *
            </label>
            <Input
              value={formData.description || ''}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Descrição breve"
              className="min-h-16"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold mb-2 text-foreground">
                Preço (R$) *
              </label>
              <Input
                type="number"
                value={formData.price || 0}
                onChange={(e) => handleChange('price', parseFloat(e.target.value))}
                placeholder="0.00"
                step="0.01"
                min="0"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 text-foreground">
                Categoria *
              </label>
              <select
                value={formData.category || 'salgados'}
                onChange={(e) => handleChange('category', e.target.value)}
                className="w-full border-2 border-border rounded-lg px-3 py-2 bg-white"
              >
                <option value="salgados">Salgado</option>
                <option value="doces">Doce</option>
                <option value="bebidas">Bebida</option>
              </select>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            onClick={handleSubmit}
            className="bg-primary hover:bg-primary/90"
          >
            {isNew ? 'Criar' : 'Salvar'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

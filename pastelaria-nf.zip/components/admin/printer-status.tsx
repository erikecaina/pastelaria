'use client'

import { useState } from 'react'
import { Bluetooth, Volume2, VolumeX, Printer } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { usePrinter } from '@/contexts/printer-context'

interface PrinterStatusProps {
  soundEnabled: boolean
  onToggleSound: () => void
}

export function PrinterStatus({ soundEnabled, onToggleSound }: PrinterStatusProps) {
  const {
    isConnected,
    connectedDevice,
    error,
    isScanning,
    connectPrinter,
    disconnect,
  } = usePrinter()

  const [showPairingModal, setShowPairingModal] = useState(false)

  const handleConnect = async () => {
    setShowPairingModal(true)
    const success = await connectPrinter()
    if (success) {
      setTimeout(() => setShowPairingModal(false), 1000)
    }
  }

  const handleDisconnect = async () => {
    await disconnect()
    setShowPairingModal(false)
  }

  return (
    <>
      <Card className="p-6 bg-white border-2 border-gray-200 rounded-2xl shadow-lg">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h3 className="font-black text-xl text-foreground mb-1">
              Impressora Bluetooth
            </h3>
            <p className="text-sm text-muted-foreground">
              MPT-II (Impressora térmica de 80mm)
            </p>
          </div>
          <Printer className="w-8 h-8 text-purple-600" />
        </div>

        <div className="space-y-4">
          {isConnected ? (
            <div className="flex items-center gap-3 p-4 bg-green-50 border-2 border-green-200 rounded-xl">
              <Bluetooth className="w-5 h-5 text-green-600" />
              <div className="flex-1">
                <p className="font-bold text-green-700 text-sm">Conectada</p>
                <p className="text-xs text-green-600">
                  {connectedDevice?.name || 'Impressora Bluetooth'}
                </p>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-3 p-4 bg-red-50 border-2 border-red-200 rounded-xl">
              <Bluetooth className="w-5 h-5 text-red-600" />
              <div>
                <p className="font-bold text-red-700 text-sm">Desconectada</p>
                <p className="text-xs text-red-600">Clique para conectar</p>
              </div>
            </div>
          )}

          {error && (
            <div className="p-3 bg-yellow-50 border-2 border-yellow-200 rounded-xl">
              <p className="text-xs text-yellow-700 font-semibold">{error}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            {isConnected ? (
              <Button
                onClick={handleDisconnect}
                className="bg-red-600 hover:bg-red-700 text-white font-bold"
              >
                <Bluetooth className="w-4 h-4 mr-2" />
                Desconectar
              </Button>
            ) : (
              <Button
                onClick={handleConnect}
                disabled={isScanning}
                className="bg-purple-600 hover:bg-purple-700 text-white font-bold disabled:opacity-50"
              >
                <Bluetooth className="w-4 h-4 mr-2" />
                {isScanning ? 'Procurando...' : 'Conectar'}
              </Button>
            )}

            <Button
              onClick={onToggleSound}
              variant={soundEnabled ? 'default' : 'outline'}
              className={`font-bold ${soundEnabled ? 'bg-green-50 text-green-700 border-green-200 hover:bg-green-100' : ''}`}
            >
              {soundEnabled ? (
                <>
                  <Volume2 className="w-4 h-4 mr-2" />
                  Som Ativado
                </>
              ) : (
                <>
                  <VolumeX className="w-4 h-4 mr-2" />
                  Som Desativado
                </>
              )}
            </Button>
          </div>
        </div>
      </Card>

      {/* Modal de Pareamento (igual Supremo Açaí) */}
      {showPairingModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-sm p-0 bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-purple-600 to-purple-700 px-6 py-4">
              <p className="text-white font-semibold text-sm">
                O nfpastelaria.live deseja realizar o pareamento
              </p>
            </div>

            <div className="p-6">
              {error ? (
                <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4 rounded">
                  <p className="text-red-800 text-sm font-semibold mb-1">Erro:</p>
                  <p className="text-red-700 text-xs">{error}</p>
                </div>
              ) : isConnected ? (
                <div className="flex flex-col items-center justify-center text-center py-8">
                  <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-3">
                    <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-green-700 font-bold text-sm">Conectado!</p>
                  <p className="text-green-600 text-xs mt-1">{connectedDevice?.name}</p>
                </div>
              ) : isScanning ? (
                <div className="flex flex-col items-center justify-center text-center py-8">
                  <div className="w-8 h-8 border-4 border-gray-200 border-t-blue-600 rounded-full animate-spin mb-3"></div>
                  <p className="text-gray-600 text-sm font-medium">Procurando impressora...</p>
                  <p className="text-gray-500 text-xs mt-2">Selecione a impressora no popup do navegador</p>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center text-center py-8">
                  <p className="text-gray-600 text-sm">Clique em "Parear" para buscar impressoras</p>
                </div>
              )}

              <div className="flex items-center gap-3 my-6">
                <div className="flex-1 h-px bg-gray-200"></div>
                <button className="p-1.5 rounded-full hover:bg-gray-100 transition-colors text-gray-400">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                  </svg>
                </button>
                <div className="flex-1 h-px bg-gray-200"></div>
              </div>

              <p className="text-center text-gray-500 text-xs font-medium">
                {isScanning ? 'Verificando...' : 'Toque em Parear no seu dispositivo'}
              </p>
            </div>

            <div className="flex gap-3 px-6 py-4 bg-gray-50 border-t border-gray-200">
              {isScanning && (
                <div className="flex-1 flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-blue-500 animate-pulse"></div>
                  <p className="text-xs text-gray-600 font-medium">Verificando...</p>
                </div>
              )}
              <Button
                onClick={() => setShowPairingModal(false)}
                className="px-6 font-bold text-blue-600 border-2 border-blue-600 bg-white hover:bg-blue-50"
              >
                Cancelar
              </Button>
              {!isConnected && !isScanning && (
                <Button
                  onClick={handleConnect}
                  className="px-6 font-bold bg-blue-600 text-white hover:bg-blue-700"
                >
                  Parear
                </Button>
              )}
            </div>
          </Card>
        </div>
      )}
    </>
  )
}

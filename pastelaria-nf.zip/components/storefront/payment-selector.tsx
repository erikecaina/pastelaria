'use client'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { useState } from 'react'

interface PaymentSelectorProps {
  onSelectPayment: (method: string, change?: number) => void
  total: number
}

export function PaymentSelector({ onSelectPayment, total }: PaymentSelectorProps) {
  const [selectedMethod, setSelectedMethod] = useState('dinheiro')
  const [wantChange, setWantChange] = useState(false)
  const [changeAmount, setChangeAmount] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})

  const handleSubmit = () => {
    console.log('[v0] 🔴 BOTÃO CLICADO - handleSubmit iniciado')
    console.log('[v0] onSelectPayment tipo:', typeof onSelectPayment)
    const newErrors: Record<string, string> = {}

    if (selectedMethod === 'dinheiro' && wantChange) {
      const change = parseFloat(changeAmount)
      if (!changeAmount || isNaN(change) || change < total) {
        newErrors.changeAmount = `Valor deve ser maior que R$ ${total.toFixed(2)}`
      }
    }

    if (Object.keys(newErrors).length > 0) {
      console.log('[v0] ❌ Validação falhou:', newErrors)
      setErrors(newErrors)
      return
    }

    console.log('[v0] ✅ Validação OK - Chamando onSelectPayment com método:', selectedMethod)
    const change = wantChange ? parseFloat(changeAmount) : undefined
    onSelectPayment(selectedMethod, change)
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-bold text-lg text-foreground mb-4">
          Forma de Pagamento
        </h3>

        <RadioGroup value={selectedMethod} onValueChange={setSelectedMethod}>
          <div className="space-y-3">
            <div className="flex items-center border-2 rounded-lg p-4 cursor-pointer hover:bg-muted transition-colors"
              onClick={() => setSelectedMethod('dinheiro')}
            >
              <RadioGroupItem value="dinheiro" id="dinheiro" />
              <label htmlFor="dinheiro" className="ml-3 cursor-pointer font-semibold text-foreground flex-1">
                Dinheiro
              </label>
            </div>

            <div className="flex items-center border-2 rounded-lg p-4 cursor-pointer hover:bg-muted transition-colors"
              onClick={() => setSelectedMethod('pix')}
            >
              <RadioGroupItem value="pix" id="pix" />
              <label htmlFor="pix" className="ml-3 cursor-pointer font-semibold text-foreground flex-1">
                PIX
              </label>
            </div>

            <div className="flex items-center border-2 rounded-lg p-4 cursor-pointer hover:bg-muted transition-colors"
              onClick={() => setSelectedMethod('credito')}
            >
              <RadioGroupItem value="credito" id="credito" />
              <label htmlFor="credito" className="ml-3 cursor-pointer font-semibold text-foreground flex-1">
                Cartão de Crédito
              </label>
            </div>

            <div className="flex items-center border-2 rounded-lg p-4 cursor-pointer hover:bg-muted transition-colors"
              onClick={() => setSelectedMethod('debito')}
            >
              <RadioGroupItem value="debito" id="debito" />
              <label htmlFor="debito" className="ml-3 cursor-pointer font-semibold text-foreground flex-1">
                Cartão de Débito
              </label>
            </div>
          </div>
        </RadioGroup>
      </div>

      {selectedMethod === 'dinheiro' && (
        <div className="bg-muted p-4 rounded-lg space-y-4">
          <div>
            <h4 className="font-semibold text-foreground mb-3">Precisa de troco?</h4>
            <div className="flex gap-3">
              <Button
                variant={!wantChange ? 'default' : 'outline'}
                className={!wantChange ? 'bg-primary hover:bg-primary/90' : ''}
                onClick={() => setWantChange(false)}
              >
                Não
              </Button>
              <Button
                variant={wantChange ? 'default' : 'outline'}
                className={wantChange ? 'bg-primary hover:bg-primary/90' : ''}
                onClick={() => setWantChange(true)}
              >
                Sim
              </Button>
            </div>
          </div>

          {wantChange && (
            <div>
              <label className="block text-sm font-semibold mb-2 text-foreground">
                Troco para quanto? (R$)
              </label>
              <Input
                type="number"
                placeholder={`Ex: ${(total * 2).toFixed(2)}`}
                value={changeAmount}
                onChange={(e) => {
                  setChangeAmount(e.target.value)
                  if (errors.changeAmount) {
                    setErrors((prev) => ({ ...prev, changeAmount: '' }))
                  }
                }}
                step="0.01"
                min={total}
                className="border-2"
              />
              {errors.changeAmount && (
                <p className="text-destructive text-sm mt-1">{errors.changeAmount}</p>
              )}
            </div>
          )}
        </div>
      )}

      <Button
        onClick={handleSubmit}
        size="lg"
        className="w-full bg-primary hover:bg-primary/90 text-white font-bold"
      >
        Enviar pelo WhatsApp
      </Button>
    </div>
  )
}

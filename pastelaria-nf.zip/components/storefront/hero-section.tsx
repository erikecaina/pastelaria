'use client'

import Image from 'next/image'
import Link from 'next/link'
import { Bike, Clock, MapPin, Zap } from 'lucide-react'
import React from 'react'
import { useSyncData } from '@/hooks/use-sync-data'

export function HeroSection() {
  return (
    <div className="relative w-full overflow-hidden">
      {/* Gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary via-primary/95 to-primary/85">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-20 -left-40 text-white/5 font-black text-[400px] leading-none select-none">
            NF
          </div>
          <div className="absolute -bottom-32 -right-56 text-white/5 font-black text-[500px] leading-none select-none">
            NF
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 py-12 md:py-20">
        {/* Logo badge */}
        <div className="flex justify-center mb-8">
          <div className="relative">
            <div className="absolute inset-0 bg-secondary rounded-full blur-xl opacity-50" />
            <div className="relative bg-secondary rounded-full p-3 shadow-2xl">
              <div className="relative w-14 h-14 md:w-16 md:h-16">
                <Image
                  src="/logo.png"
                  alt="NF Pastelaria"
                  fill
                  className="object-contain"
                  priority
                />
              </div>
            </div>
          </div>
        </div>

        {/* Title and Info - Dynamic Content */}
        <HeroContent />

        {/* Promotions banner */}
        <PromoBanner />
      </div>
    </div>
  )
}

function HeroContent() {
  const [storeData] = useSyncData('nf-pastelaria-store-config', {
    name: 'NF Pastelaria',
    slogan: 'O sabor que você ama!',
    deliveryTime: '30-45 min',
    openingHours: { monday: '08:00 - 22:00' }
  })
  const [mounted, setMounted] = React.useState(false)

  React.useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <>
      <h1 className="text-center text-4xl md:text-6xl font-black text-white mb-3 drop-shadow-lg text-balance">
        {storeData.name}
      </h1>
      <p className="text-center text-lg md:text-xl text-white/90 font-semibold mb-6 drop-shadow">
        {storeData.slogan}
      </p>
      <div className="flex flex-wrap justify-center gap-2 md:gap-3 mb-8 md:mb-12">
        <div className="bg-white rounded-full px-4 md:px-5 py-2 md:py-3 flex items-center gap-2 shadow-lg">
          <Bike className="w-4 h-4 text-primary flex-shrink-0" />
          <span className="text-xs md:text-sm font-bold text-foreground">
            {storeData.deliveryTime}
          </span>
        </div>
        <div className="bg-white rounded-full px-4 md:px-5 py-2 md:py-3 flex items-center gap-2 shadow-lg">
          <Clock className="w-4 h-4 text-primary flex-shrink-0" />
          <span className="text-xs md:text-sm font-bold text-foreground">
            {storeData.openingHours.monday}
          </span>
        </div>
        <div className="bg-white rounded-full px-4 md:px-5 py-2 md:py-3 flex items-center gap-2 shadow-lg">
          <MapPin className="w-4 h-4 text-secondary flex-shrink-0" />
          <span className="text-xs md:text-sm font-bold text-foreground">
            Entrega
          </span>
        </div>
      </div>
    </>
  )
}

function PromoBanner() {
  const [allPromotions] = useSyncData('nf-pastelaria-promotions', [])
  const [mounted, setMounted] = React.useState(false)

  React.useEffect(() => {
    setMounted(true)
  }, [])

  const promotions = Array.isArray(allPromotions) 
    ? allPromotions.filter((p: any) => p.active)
    : []

  if (!mounted || promotions.length === 0) return null

  return (
    <div className="mb-6 md:mb-8 space-y-3">
      {promotions.map((promo, idx) => (
        <Link key={idx} href="/menu" className="block">
          <div className="relative mx-auto max-w-2xl rounded-2xl p-6 md:p-8 shadow-2xl hover:shadow-3xl transition-shadow overflow-hidden"
            style={{
              background: `linear-gradient(to right, ${promo.bgColor || '#FF6B35'}, ${promo.bgColorEnd || '#FF8C5A'})`
            }}>
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 right-0 text-white/20 font-black text-6xl md:text-8xl">
                {promo.icon || '🎉'}
              </div>
            </div>

            <div className="relative z-10 flex gap-4 items-start md:items-center">
              <div className="flex-shrink-0">
                <div className="bg-white rounded-full p-3 shadow-lg">
                  <Zap className="w-6 h-6 md:w-8 md:h-8 text-primary" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs md:text-sm font-black text-white uppercase tracking-wider mb-1">
                  {promo.title}
                </p>
                <h2 className="text-lg md:text-2xl font-black text-white mb-1">
                  {promo.description}
                </h2>
                <p className="text-sm md:text-base text-white/90 font-medium">
                  {promo.subtitle}
                </p>
              </div>
            </div>
          </div>
        </Link>
      ))}
    </div>
  )
}

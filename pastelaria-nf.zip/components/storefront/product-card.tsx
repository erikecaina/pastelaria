'use client'

import { Product } from '@/lib/types'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { ShoppingCart, Plus } from 'lucide-react'

interface ProductCardProps {
  product: Product
  onSelect: (product: Product) => void
}

export function ProductCard({ product, onSelect }: ProductCardProps) {
  return (
    <div className="group bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 h-full flex flex-col cursor-pointer">
      {/* Image container */}
      <div className="relative w-full h-56 bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden">
        <Image
          src={product.image || '/pastel-placeholder.png'}
          alt={product.name}
          fill
          className="object-cover group-hover:scale-110 transition-transform duration-300"
        />
        
        {/* Category badge */}
        <div className="absolute top-3 right-3 bg-primary text-white px-3 py-1 rounded-full text-xs font-bold uppercase">
          {product.category === 'salgados' && 'Salgado'}
          {product.category === 'doces' && 'Doce'}
          {product.category === 'bebidas' && 'Bebida'}
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-col flex-1 p-5 md:p-6">
        <h3 className="font-bold text-lg md:text-xl text-foreground mb-2 line-clamp-2">
          {product.name}
        </h3>
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2 flex-1 leading-relaxed">
          {product.description}
        </p>

        {/* Footer */}
        <div className="flex items-center justify-between mt-auto gap-3">
          <div>
            <span className="text-xs text-muted-foreground">a partir de</span>
            <p className="text-3xl font-bold text-primary">
              R$ {product.price.toFixed(2)}
            </p>
          </div>
          <Button
            onClick={() => onSelect(product)}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-white rounded-full p-3 h-auto shadow-lg hover:shadow-xl transition-all"
          >
            <Plus className="w-6 h-6" />
          </Button>
        </div>
      </div>
    </div>
  )
}

'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'

interface CategoryFilterProps {
  selectedCategory: string
  onCategoryChange: (category: string) => void
}

const categories = [
  { id: 'todos', label: 'Todos' },
  { id: 'salgados', label: 'Salgados' },
  { id: 'doces', label: 'Doces' },
  { id: 'bebidas', label: 'Bebidas' },
]

export function CategoryFilter({
  selectedCategory,
  onCategoryChange,
}: CategoryFilterProps) {
  return (
    <div className="w-full bg-white sticky top-0 z-20 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 py-4 md:py-5">
        <div className="flex gap-2 md:gap-3 overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
          {categories.map((category) => (
            <Button
              key={category.id}
              onClick={() => onCategoryChange(category.id)}
              className={`
                flex-shrink-0 rounded-full font-bold text-sm md:text-base px-5 md:px-6 py-2 md:py-2.5 whitespace-nowrap transition-all
                ${
                  selectedCategory === category.id
                    ? 'bg-primary hover:bg-primary/90 text-white shadow-md'
                    : 'bg-gray-100 text-foreground hover:bg-gray-200'
                }
              `}
              variant="ghost"
            >
              {category.label}
            </Button>
          ))}
        </div>
      </div>
    </div>
  )
}

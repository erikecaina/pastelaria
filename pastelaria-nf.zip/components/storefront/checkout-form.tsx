'use client'

import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { useState, useEffect } from 'react'
import { RotateCcw } from 'lucide-react'

interface CheckoutFormProps {
  onNext: (data: {
    name: string
    street: string
    number: string
    neighborhood: string
    complement?: string
    referencePoint?: string
  }) => void
}

export function CheckoutForm({ onNext }: CheckoutFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    street: '',
    number: '',
    neighborhood: '',
    complement: '',
    referencePoint: '',
  })
  const [isMounted, setIsMounted] = useState(false)

  const [errors, setErrors] = useState<Record<string, string>>({})

  // Carregar dados salvos do localStorage na inicialização
  useEffect(() => {
    try {
      const savedData = localStorage.getItem('customer_delivery_data')
      if (savedData) {
        const parsed = JSON.parse(savedData)
        setFormData(parsed)
      }
    } catch (error) {
      console.error('[v0] Erro ao carregar dados salvos:', error)
    }
    setIsMounted(true)
  }, [])

  // Salvar dados no localStorage sempre que formData mudar
  useEffect(() => {
    if (isMounted) {
      try {
        localStorage.setItem('customer_delivery_data', JSON.stringify(formData))
      } catch (error) {
        console.error('[v0] Erro ao salvar dados:', error)
      }
    }
  }, [formData, isMounted])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }))
    }
  }

  const handleClearData = () => {
    const confirmed = window.confirm('Tem certeza que deseja limpar todos os dados salvos?')
    if (confirmed) {
      try {
        localStorage.removeItem('customer_delivery_data')
        setFormData({
          name: '',
          street: '',
          number: '',
          neighborhood: '',
          complement: '',
          referencePoint: '',
        })
      } catch (error) {
        console.error('[v0] Erro ao limpar dados:', error)
      }
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const newErrors: Record<string, string> = {}

    if (!formData.name.trim()) newErrors.name = 'Nome é obrigatório'
    if (!formData.street.trim()) newErrors.street = 'Rua é obrigatória'
    if (!formData.number.trim()) newErrors.number = 'Número é obrigatório'
    if (!formData.neighborhood.trim()) newErrors.neighborhood = 'Bairro é obrigatório'

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    // Passa os dados para a próxima etapa (pagamento)
    // O pedido será criado apenas quando o cliente confirmar o envio pelo WhatsApp
    onNext(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-semibold mb-2 text-foreground">
          Seu nome *
        </label>
        <Input
          type="text"
          name="name"
          placeholder="Digite seu nome"
          value={formData.name}
          onChange={handleChange}
          className="border-2"
        />
        {errors.name && (
          <p className="text-destructive text-sm mt-1">{errors.name}</p>
        )}
      </div>

      <div>
        <h3 className="font-semibold mb-4 text-foreground">Endereço de Entrega</h3>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold mb-2 text-foreground">
              Rua *
            </label>
            <Input
              type="text"
              name="street"
              placeholder="Nome da rua"
              value={formData.street}
              onChange={handleChange}
              className="border-2"
            />
            {errors.street && (
              <p className="text-destructive text-sm mt-1">{errors.street}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold mb-2 text-foreground">
                Número *
              </label>
              <Input
                type="text"
                name="number"
                placeholder="Número"
                value={formData.number}
                onChange={handleChange}
                className="border-2"
              />
              {errors.number && (
                <p className="text-destructive text-sm mt-1">{errors.number}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 text-foreground">
                Bairro *
              </label>
              <Input
                type="text"
                name="neighborhood"
                placeholder="Bairro"
                value={formData.neighborhood}
                onChange={handleChange}
                className="border-2"
              />
              {errors.neighborhood && (
                <p className="text-destructive text-sm mt-1">
                  {errors.neighborhood}
                </p>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2 text-foreground">
              Complemento (Opcional)
            </label>
            <Input
              type="text"
              name="complement"
              placeholder="Ex: Apt 101, Casa 2"
              value={formData.complement}
              onChange={handleChange}
              className="border-2"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2 text-foreground">
              Ponto de Referência (Opcional)
            </label>
            <Input
              type="text"
              name="referencePoint"
              placeholder="Ex: Próximo ao supermercado, Portão azul, Perto da farmácia"
              value={formData.referencePoint}
              onChange={handleChange}
              className="border-2"
            />
          </div>
        </div>
      </div>

      <div className="flex gap-3">
        <Button
          type="submit"
          size="lg"
          className="flex-1 bg-primary hover:bg-primary/90 text-white font-bold"
        >
          Continuar para Pagamento
        </Button>
        <Button
          type="button"
          size="lg"
          variant="outline"
          onClick={handleClearData}
          className="border-2 border-gray-300 hover:border-gray-400"
          title="Limpar dados salvos"
        >
          <RotateCcw size={20} />
        </Button>
      </div>
    </form>
  )
}

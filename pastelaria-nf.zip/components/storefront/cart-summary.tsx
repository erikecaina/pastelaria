'use client'

import { useCart } from '@/hooks/use-cart'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { X, Minus, Plus } from 'lucide-react'
import Link from 'next/link'
import { CartItem } from '@/lib/types'

interface CartSummaryProps {
  items?: CartItem[]
  onCheckout?: () => void
}

export function CartSummary({ items: propItems, onCheckout }: CartSummaryProps = {}) {
  const { items: cartItems, removeItem, updateQuantity, subtotal, total } = useCart()
  const items = propItems || cartItems
  const DELIVERY_FEE = 2.0

  if (items.length === 0) {
    return (
      <div className="bg-gradient-to-br from-gray-50 to-white rounded-2xl shadow-lg p-12 text-center border-2 border-dashed border-primary/30">
        <div className="text-5xl mb-4">🛒</div>
        <p className="text-muted-foreground text-lg mb-6 font-medium">
          Seu carrinho está vazio
        </p>
        <p className="text-sm text-muted-foreground mb-6">
          Escolha seus pastéis favoritos para começar
        </p>
        <Link href="/menu">
          <Button className="bg-primary hover:bg-primary/90 text-white font-bold px-8 py-6 rounded-full text-lg">
            Continuar Comprando
          </Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
      <div className="p-6 md:p-8 border-b border-gray-200">
        <h2 className="text-3xl font-bold text-foreground mb-6">Seu Pedido</h2>

        <div className="space-y-3">
          {items.map((item) => (
            <div
              key={item.product.id}
              className="flex items-center justify-between gap-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
            >
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-foreground line-clamp-1">
                  {item.product.name}
                </h3>
                {item.observations && (
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-1">
                    Obs: {item.observations}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-1 bg-white rounded-lg border border-gray-200 p-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    updateQuantity(item.product.id, item.quantity - 1)
                  }
                  className="h-7 w-7 p-0 rounded hover:bg-primary/10"
                >
                  <Minus className="w-3 h-3" />
                </Button>
                <span className="w-6 text-center font-bold text-sm">
                  {item.quantity}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    updateQuantity(item.product.id, item.quantity + 1)
                  }
                  className="h-7 w-7 p-0 rounded hover:bg-primary/10"
                >
                  <Plus className="w-3 h-3" />
                </Button>
              </div>

              <div className="text-right w-20">
                <p className="font-bold text-primary text-sm">
                  R$ {(item.product.price * item.quantity).toFixed(2)}
                </p>
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => removeItem(item.product.id)}
                className="text-destructive hover:bg-destructive/20 h-8 w-8 p-0 rounded"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-br from-gray-50 to-gray-100 p-6 md:p-8 space-y-4 border-t border-gray-200">
        <div className="flex justify-between items-center">
          <span className="text-muted-foreground font-medium">Subtotal</span>
          <span className="font-bold text-foreground text-lg">
            R$ {subtotal.toFixed(2)}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-muted-foreground font-medium">Taxa de Entrega</span>
          <span className="font-bold text-foreground text-lg">
            R$ {DELIVERY_FEE.toFixed(2)}
          </span>
        </div>
        <div className="border-t-2 border-gray-300 pt-4 flex justify-between items-center">
          <span className="text-xl font-bold text-foreground">Total</span>
          <span className="text-4xl font-bold text-primary">
            R$ {total.toFixed(2)}
          </span>
        </div>
      </div>

      <div className="p-6 md:p-8">
        {onCheckout ? (
          <Button
            onClick={onCheckout}
            size="lg"
            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 rounded-full text-lg shadow-lg hover:shadow-xl transition-all"
          >
            Continuar para Pagamento
          </Button>
        ) : (
          <Link href="/checkout">
            <Button
              size="lg"
              className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 rounded-full text-lg shadow-lg hover:shadow-xl transition-all"
            >
              Finalizar Pedido
            </Button>
          </Link>
        )}
        <Link href="/menu" className="block mt-3">
          <Button
            size="lg"
            variant="outline"
            className="w-full border-2 border-gray-300 hover:border-primary text-foreground py-6 rounded-full text-lg"
          >
            Continuar Comprando
          </Button>
        </Link>
      </div>
    </div>
  )
}

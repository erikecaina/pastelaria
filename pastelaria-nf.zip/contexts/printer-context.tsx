'use client'

import { createContext, useContext, ReactNode } from 'react'
import { usePrinterBluetooth } from '@/hooks/use-printer-bluetooth'

interface PrinterContextType {
  isConnected: boolean
  connectedDevice: { id: string; name: string | undefined } | null
  error: string | null
  isScanning: boolean
  connectPrinter: () => Promise<boolean>
  disconnect: () => Promise<void>
  printOrder: (order: any) => Promise<boolean>
}

const PrinterContext = createContext<PrinterContextType | undefined>(undefined)

export function PrinterProvider({ children }: { children: ReactNode }) {
  const printerHook = usePrinterBluetooth()

  return (
    <PrinterContext.Provider value={printerHook}>
      {children}
    </PrinterContext.Provider>
  )
}

export function usePrinter() {
  const context = useContext(PrinterContext)
  if (!context) {
    throw new Error('usePrinter deve ser usado dentro de PrinterProvider')
  }
  return context
}

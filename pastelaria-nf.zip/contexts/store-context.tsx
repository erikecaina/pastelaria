'use client'

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react'

export interface StoreConfig {
  // Informações da Loja
  name: string
  slogan: string
  logo?: string
  
  // Contato
  whatsapp: string
  phone?: string
  email?: string
  
  // Endereço
  address?: string
  city?: string
  neighborhood?: string
  
  // Configurações
  deliveryFee: number
  minOrderValue: number
  deliveryTime?: string
  
  // Status
  isOpen: boolean
  openingHours?: {
    monday?: string
    tuesday?: string
    wednesday?: string
    thursday?: string
    friday?: string
    saturday?: string
    sunday?: string
  }
}

interface StoreContextType {
  storeConfig: StoreConfig
  updateStoreConfig: (config: Partial<StoreConfig>) => void
  
  // Listener para mudanças
  subscribeToChanges: (callback: () => void) => () => void
}

const DEFAULT_STORE_CONFIG: StoreConfig = {
  name: 'NF Pastelaria',
  slogan: 'O sabor que você ama!',
  whatsapp: '8398743-3682',
  deliveryFee: 2.0,
  minOrderValue: 0,
  isOpen: true,
  openingHours: {
    monday: '08:00 - 22:00',
    tuesday: '08:00 - 22:00',
    wednesday: '08:00 - 22:00',
    thursday: '08:00 - 22:00',
    friday: '08:00 - 23:00',
    saturday: '09:00 - 23:00',
    sunday: '09:00 - 22:00',
  }
}

const StoreContext = createContext<StoreContextType | undefined>(undefined)

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [storeConfig, setStoreConfig] = useState<StoreConfig>(DEFAULT_STORE_CONFIG)
  const [listeners, setListeners] = useState<(() => void)[]>([])
  const [isHydrated, setIsHydrated] = useState(false)

  // Carregar configurações do localStorage ao montar
  useEffect(() => {
    const storedConfig = localStorage.getItem('nf-pastelaria-store-config')
    if (storedConfig) {
      try {
        setStoreConfig(JSON.parse(storedConfig))
      } catch (error) {
        console.error('[StoreContext] Erro ao carregar config:', error)
      }
    }
    setIsHydrated(true)
  }, [])

  // Listener para mudanças no localStorage de outras abas
  useEffect(() => {
    if (!isHydrated) return

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'nf-pastelaria-store-config' && e.newValue) {
        try {
          setStoreConfig(JSON.parse(e.newValue))
          listeners.forEach(callback => callback())
        } catch (error) {
          console.error('[StoreContext] Erro ao sincronizar:', error)
        }
      }
    }

    window.addEventListener('storage', handleStorageChange)
    return () => window.removeEventListener('storage', handleStorageChange)
  }, [listeners, isHydrated])

  // Listener para mudanças dentro da mesma aba (custom event)
  useEffect(() => {
    if (!isHydrated) return

    const handleCustomEvent = () => {
      listeners.forEach(callback => callback())
    }

    window.addEventListener('store-config-changed', handleCustomEvent)
    return () => window.removeEventListener('store-config-changed', handleCustomEvent)
  }, [listeners, isHydrated])

  const updateStoreConfig = useCallback((config: Partial<StoreConfig>) => {
    setStoreConfig(prev => {
      const updated = { ...prev, ...config }
      // Persistir no localStorage
      localStorage.setItem('nf-pastelaria-store-config', JSON.stringify(updated))
      // Disparar evento customizado para listeners na mesma aba
      window.dispatchEvent(new Event('store-config-changed'))
      // Notificar listeners
      listeners.forEach(callback => callback())
      return updated
    })
  }, [listeners])

  const subscribeToChanges = useCallback((callback: () => void) => {
    setListeners(prev => [...prev, callback])
    // Retornar função para unsubscribe
    return () => {
      setListeners(prev => prev.filter(cb => cb !== callback))
    }
  }, [])

  if (!isHydrated) {
    return <>{children}</>
  }

  return (
    <StoreContext.Provider value={{ storeConfig, updateStoreConfig, subscribeToChanges }}>
      {children}
    </StoreContext.Provider>
  )
}

export function useStore() {
  const context = useContext(StoreContext)
  if (!context) {
    throw new Error('useStore deve ser usado dentro de StoreProvider')
  }
  return context
}

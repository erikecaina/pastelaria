'use client'

import { createContext, useContext, useState, useEffect } from 'react'

export interface OrderItem {
  productName: string
  quantity: number
  price: number
  subtotal: number
  observation?: string
}

export interface Order {
  id: string
  customerName: string
  phone: string
  address: string
  items: OrderItem[]
  total: number
  status: 'pendente' | 'impresso' | 'entregue'
  created_at?: string
}

interface OrdersContextType {
  orders: Order[]
  addOrder: (order: Omit<Order, 'id' | 'status' | 'created_at'>) => void
  updateOrderStatus: (orderId: string, status: 'pendente' | 'impresso' | 'entregue') => Promise<void>
  refreshOrders: () => Promise<void>
}

const OrdersContext = createContext<OrdersContextType | undefined>(undefined)

export function OrdersProvider({ children }: { children: React.ReactNode }) {
  const [orders, setOrders] = useState<Order[]>([])

  // Carregar pedidos do Supabase
  const loadOrders = async () => {
    try {
      console.log('[v0] OrdersContext: Iniciando loadOrders')
      const response = await fetch(`/api/admin/orders?t=${Date.now()}`, {
        cache: 'no-store',
        method: 'GET',
      })
      
      console.log('[v0] Response status:', response.status)
      
      if (!response.ok) {
        console.error('[v0] Erro na resposta:', response.status, response.statusText)
        return
      }
      
      const data = await response.json()
      console.log('[v0] Data recebida:', data)

      if (data.orders && Array.isArray(data.orders)) {
        console.log('[v0] Total de pedidos:', data.orders.length)
        const transformedOrders = data.orders.map((order: any) => ({
          id: order.id,
          customerName: order.customer_name || 'Sem nome',
          phone: order.customer_phone || order.phone || '',
          address: order.customer_address || order.address || '',
          items: typeof order.items === 'string' ? JSON.parse(order.items) : (order.items || []),
          total: order.total || 0,
          status: order.status || 'pendente',
          created_at: order.created_at || new Date().toISOString(),
        }))
        console.log('[v0] Pedidos transformados:', transformedOrders)
        setOrders(transformedOrders)
        console.log('[v0] ✅ Orders state atualizado com', transformedOrders.length, 'pedidos')
      } else {
        console.log('[v0] Nenhum pedido recebido')
        setOrders([])
      }
    } catch (error) {
      console.error('[v0] ❌ Erro ao carregar pedidos:', error)
    }
  }

  // Polling inicial e contínuo (a cada 3 segundos)
  useEffect(() => {
    console.log('[v0] OrdersContext: useEffect iniciado')
    loadOrders()
    const interval = setInterval(loadOrders, 3000)
    return () => clearInterval(interval)
  }, [])

  const addOrder = (order: Omit<Order, 'id' | 'status' | 'created_at'>) => {
    // Apenas para testes, na prática o pedido é salvo via API
  }

  const updateOrderStatus = async (orderId: string, status: 'pendente' | 'impresso' | 'entregue') => {
    try {
      const response = await fetch('/api/orders', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId, status }),
      })
      if (response.ok) {
        await loadOrders()
      }
    } catch (error) {
      console.error('Erro ao atualizar status:', error)
    }
  }

  const refreshOrders = async () => {
    await loadOrders()
  }

  return (
    <OrdersContext.Provider value={{ orders, addOrder, updateOrderStatus, refreshOrders }}>
      {children}
    </OrdersContext.Provider>
  )
}

export function useOrders() {
  const context = useContext(OrdersContext)
  if (context === undefined) {
    throw new Error('useOrders must be used within OrdersProvider')
  }
  return context
}

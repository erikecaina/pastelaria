'use client'

import React, { createContext, useContext, useState, useCallback, ReactNode, useEffect } from 'react'

export interface Product {
  id: string
  name: string
  description: string
  price: number
  image?: string
  category: 'salgados' | 'doces' | 'bebidas'
  available?: boolean
}

interface ProductsContextType {
  products: Product[]
  addProduct: (product: Omit<Product, 'id'>) => Promise<void>
  updateProduct: (id: string, product: Partial<Product>) => Promise<void>
  deleteProduct: (id: string) => Promise<void>
  refreshProducts: () => Promise<void>
}

const ProductsContext = createContext<ProductsContextType | undefined>(undefined)

export function ProductsProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>([])

  // Buscar produtos da API
  const refreshProducts = useCallback(async () => {
    try {
      const response = await fetch('/api/products')
      const data = await response.json()
      
      if (data.products) {
        setProducts(data.products)
      }
    } catch (error) {
      console.error('[v0] Erro ao carregar produtos:', error)
    }
  }, [])

  // Carregar produtos na inicialização
  useEffect(() => {
    refreshProducts()

    // Polling: atualizar produtos a cada 5 segundos
    const interval = setInterval(refreshProducts, 5000)
    return () => clearInterval(interval)
  }, [refreshProducts])

  // Adicionar produto
  const addProduct = useCallback(async (productData: Omit<Product, 'id'>) => {
    try {
      const response = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productData),
      })

      if (!response.ok) throw new Error('Erro ao criar produto')

      await refreshProducts()
    } catch (error) {
      console.error('[v0] Erro ao adicionar produto:', error)
      throw error
    }
  }, [refreshProducts])

  // Atualizar produto
  const updateProduct = useCallback(async (id: string, productData: Partial<Product>) => {
    try {
      const response = await fetch('/api/products', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...productData }),
      })

      if (!response.ok) throw new Error('Erro ao atualizar produto')

      await refreshProducts()
    } catch (error) {
      console.error('[v0] Erro ao atualizar produto:', error)
      throw error
    }
  }, [refreshProducts])

  // Deletar produto
  const deleteProduct = useCallback(async (id: string) => {
    try {
      const response = await fetch(`/api/products?id=${id}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Erro ao deletar produto')

      await refreshProducts()
    } catch (error) {
      console.error('[v0] Erro ao deletar produto:', error)
      throw error
    }
  }, [refreshProducts])

  return (
    <ProductsContext.Provider value={{ products, addProduct, updateProduct, deleteProduct, refreshProducts }}>
      {children}
    </ProductsContext.Provider>
  )
}

export function useProducts() {
  const context = useContext(ProductsContext)
  if (context === undefined) {
    throw new Error('useProducts must be used within ProductsProvider')
  }
  return context
}

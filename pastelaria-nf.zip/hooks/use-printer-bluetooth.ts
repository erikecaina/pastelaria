import { useState, useCallback, useEffect, useRef } from 'react'

// Type definitions for Web Bluetooth API
declare global {
  interface Navigator {
    bluetooth: Bluetooth
  }
}

interface Bluetooth {
  requestDevice(options: RequestDeviceOptions): Promise<BluetoothDevice>
  getAvailability(): Promise<boolean>
}

interface RequestDeviceOptions {
  services?: string[]
  filters?: BluetoothDeviceFilter[]
  optionalServices?: string[]
  acceptAllDevices?: boolean
}

interface BluetoothDeviceFilter {
  services?: string[]
  name?: string
  namePrefix?: string
}

interface BluetoothDevice extends EventTarget {
  readonly id: string
  readonly name: string | undefined
  readonly gatt: BluetoothRemoteGATTServer | undefined
  readonly connected: boolean
}

interface BluetoothRemoteGATTServer extends EventTarget {
  readonly device: BluetoothDevice
  readonly connected: boolean
  connect(): Promise<BluetoothRemoteGATTServer>
  disconnect(): void
  getPrimaryService(service: string): Promise<BluetoothRemoteGATTService>
  getPrimaryServices(service?: string): Promise<BluetoothRemoteGATTService[]>
}

interface BluetoothRemoteGATTService extends EventTarget {
  readonly device: BluetoothDevice
  readonly uuid: string
  readonly isPrimary: boolean
  getCharacteristic(characteristic: string): Promise<BluetoothRemoteGATTCharacteristic>
  getCharacteristics(characteristic?: string): Promise<BluetoothRemoteGATTCharacteristic[]>
}

interface BluetoothRemoteGATTCharacteristic extends EventTarget {
  readonly service: BluetoothRemoteGATTService
  readonly uuid: string
  readonly properties: BluetoothCharacteristicProperties
  readonly value: DataView | undefined
  readValue(): Promise<DataView>
  writeValue(value: BufferSource): Promise<void>
  writeValueWithoutResponse(value: BufferSource): Promise<void>
  startNotifications(): Promise<BluetoothRemoteGATTCharacteristic>
  stopNotifications(): Promise<BluetoothRemoteGATTCharacteristic>
}

interface BluetoothCharacteristicProperties {
  readonly broadcast: boolean
  readonly read: boolean
  readonly writeWithoutResponse: boolean
  readonly write: boolean
  readonly notify: boolean
  readonly indicate: boolean
  readonly authenticatedSignedWrites: boolean
  readonly reliableWrite: boolean
  readonly writableAuxiliaries: boolean
}

// UUIDs para encontrar impressoras térmicas Bluetooth (igual Supremo Açaí)
const PRINTER_SERVICE_UUIDS = [
  '000018f0-0000-1000-8000-00805f9b34fb',
  '0000ff00-0000-1000-8000-00805f9b34fb',
  '0000ffe0-0000-1000-8000-00805f9b34fb',
  '0000fff0-0000-1000-8000-00805f9b34fb',
  '49535343-fe7d-4ae5-8fa9-9fafd205e455',
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
]

const PRINTER_CHAR_UUIDS = [
  '00002af1-0000-1000-8000-00805f9b34fb',
  '0000ff01-0000-1000-8000-00805f9b34fb',
  '0000ffe1-0000-1000-8000-00805f9b34fb',
  '0000fff1-0000-1000-8000-00805f9b34fb',
  '0000fff2-0000-1000-8000-00805f9b34fb',
  '49535343-8841-43f4-a8d4-ecbe34729bb3',
  '6e400002-b5a3-f393-e0a9-e50e24dcca9e',
]

// Comandos ESC/POS para impressoras térmicas
const ESC = 0x1b
const GS = 0x1d
const LF = 0x0a

const CMD = {
  INIT: new Uint8Array([ESC, 0x40]),
  ALIGN_LEFT: new Uint8Array([ESC, 0x61, 0]),
  ALIGN_CENTER: new Uint8Array([ESC, 0x61, 1]),
  BOLD_ON: new Uint8Array([ESC, 0x45, 1]),
  BOLD_OFF: new Uint8Array([ESC, 0x45, 0]),
  DOUBLE_SIZE: new Uint8Array([GS, 0x21, 0x11]),
  NORMAL_SIZE: new Uint8Array([GS, 0x21, 0x00]),
  CUT: new Uint8Array([GS, 0x56, 0x00]),
  FEED_LINE: new Uint8Array([LF]),
  FEED_LINES: (n: number) => new Uint8Array([ESC, 0x64, n]),
}

interface BluetoothDeviceInfo {
  id: string
  name?: string
}

interface PrinterConnection {
  device: globalThis.BluetoothDevice
  server: BluetoothRemoteGATTServer
  characteristic: BluetoothRemoteGATTCharacteristic
}

export function usePrinterBluetooth() {
  const [isConnected, setIsConnected] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [connectedDevice, setConnectedDevice] = useState<BluetoothDeviceInfo | null>(null)
  const [isScanning, setIsScanning] = useState(false)
  const printerRef = useRef<PrinterConnection | null>(null)

  useEffect(() => {
    // Bluetooth é desconectado automaticamente pelo navegador ao recarregar
    // Usuário precisa reconectar manualmente
  }, [])

  // Encontrar serviço e característica de escrita
  const findPrinterCharacteristic = async (
    server: BluetoothRemoteGATTServer
  ): Promise<BluetoothRemoteGATTCharacteristic | null> => {
    for (const serviceUuid of PRINTER_SERVICE_UUIDS) {
      try {
        const service = await server.getPrimaryService(serviceUuid)
        for (const charUuid of PRINTER_CHAR_UUIDS) {
          try {
            const characteristic = await service.getCharacteristic(charUuid)
            if (characteristic.properties.write || characteristic.properties.writeWithoutResponse) {
              console.log('[Printer] Serviço:', serviceUuid, 'Char:', charUuid)
              return characteristic
            }
          } catch { /* continuar */ }
        }
        const chars = await service.getCharacteristics()
        for (const char of chars) {
          if (char.properties.write || char.properties.writeWithoutResponse) {
            console.log('[Printer] Char encontrada:', char.uuid)
            return char
          }
        }
      } catch { /* continuar */ }
    }

    try {
      const services = await server.getPrimaryServices()
      for (const service of services) {
        const chars = await service.getCharacteristics()
        for (const char of chars) {
          if (char.properties.write || char.properties.writeWithoutResponse) {
            console.log('[Printer] Char via scan:', char.uuid)
            return char
          }
        }
      }
    } catch (err) {
      console.warn('[Printer] Erro ao listar serviços:', err)
    }

    return null
  }

  // Conexão principal (igual Supremo Açaí)
  const connectPrinter = useCallback(async (): Promise<boolean> => {
    try {
      setError(null)
      setIsScanning(true)

      if (!navigator.bluetooth) {
        setError('Web Bluetooth não suportado. Use Chrome, Edge ou Opera.')
        setIsScanning(false)
        return false
      }

      let device: globalThis.BluetoothDevice | null = null

      // Tentar com filtros de serviço primeiro
      try {
        device = await navigator.bluetooth.requestDevice({
          filters: [{ services: [PRINTER_SERVICE_UUIDS[0]] }],
          optionalServices: PRINTER_SERVICE_UUIDS,
        })
      } catch {
        // Se falhar, aceitar todos os dispositivos
        try {
          device = await navigator.bluetooth.requestDevice({
            acceptAllDevices: true,
            optionalServices: PRINTER_SERVICE_UUIDS,
          })
        } catch (err: any) {
          if (err.name === 'AbortError') {
            setError('Seleção cancelada')
          } else {
            setError('Nenhum dispositivo selecionado')
          }
          setIsScanning(false)
          return false
        }
      }

      if (!device || !device.gatt) {
        setError('Dispositivo inválido')
        setIsScanning(false)
        return false
      }

      console.log('[Printer] Conectando a:', device.name || device.id)
      const server = await device.gatt.connect()

      const characteristic = await findPrinterCharacteristic(server)
      if (!characteristic) {
        setError('Serviço de impressão não encontrado. Verifique se é uma impressora térmica.')
        await device.gatt.disconnect()
        setIsScanning(false)
        return false
      }

      printerRef.current = { device, server, characteristic }

      const deviceInfo = { id: device.id, name: device.name || 'Impressora Térmica' }
      setIsConnected(true)
      setConnectedDevice(deviceInfo)

      // Monitorar desconexão
      device.addEventListener('gattserverdisconnected', () => {
        console.log('[Printer] Desconexão detectada')
        setIsConnected(false)
        printerRef.current = null
      })

      // Inicializar impressora com pequeno delay para garantir que está pronta
      await new Promise(r => setTimeout(r, 500))
      
      try {
        const initSuccess = await sendData(CMD.INIT)
        if (!initSuccess) {
          console.warn('[Printer] Inicialização falhou, mas continuando')
        }
      } catch (err) {
        console.warn('[Printer] Erro na inicialização:', err)
      }

      console.log('[Printer] Conectado com sucesso!')
      setIsScanning(false)
      return true
    } catch (err: any) {
      setError(err.message || 'Erro ao conectar')
      console.error('[Printer] Erro:', err)
      setIsScanning(false)
      return false
    }
  }, [])

  // Verificar se a conexão ainda está válida
  const checkConnection = useCallback((): boolean => {
    if (!printerRef.current) {
      return false
    }
    if (!printerRef.current.characteristic) {
      return false
    }
    if (!printerRef.current.device?.gatt?.connected) {
      return false
    }
    return true
  }, [])

  // Enviar dados em chunks de 200 bytes (igual Supremo Açaí)
  const sendData = useCallback(async (data: Uint8Array): Promise<boolean> => {
    if (!checkConnection()) {
      setIsConnected(false)
      setError('Impressora desconectada durante envio')
      return false
    }

    try {
      const CHUNK_SIZE = 200
      const char = printerRef.current!.characteristic

      for (let i = 0; i < data.length; i += CHUNK_SIZE) {
        const chunk = data.slice(i, Math.min(i + CHUNK_SIZE, data.length))
        try {
          if (char.properties.writeWithoutResponse) {
            await char.writeValueWithoutResponse(chunk)
          } else {
            await char.writeValue(chunk)
          }
        } catch (err) {
          setIsConnected(false)
          setError('Erro ao enviar dados para impressora')
          return false
        }
        if (i + CHUNK_SIZE < data.length) {
          await new Promise(r => setTimeout(r, 20))
        }
      }
      return true
    } catch (err) {
      console.error('[Printer] Erro ao enviar:', err)
      setIsConnected(false)
      return false
    }
  }, [checkConnection])

  const textToBytes = (text: string): Uint8Array => new TextEncoder().encode(text)

  const concatBytes = (...arrays: Uint8Array[]): Uint8Array => {
    const total = arrays.reduce((sum, arr) => sum + arr.length, 0)
    const result = new Uint8Array(total)
    let offset = 0
    for (const arr of arrays) {
      result.set(arr, offset)
      offset += arr.length
    }
    return result
  }

  // Imprimir pedido formatado (igual Supremo Açaí)
  const printOrder = useCallback(async (order: {
    id: number | string
    customerName: string
    phone?: string
    address?: string
    items: Array<{ productName: string; quantity: number; price: number; observation?: string }>
    total: number
    paymentMethod?: string
    observation?: string
    storeName?: string
  }): Promise<boolean> => {
    if (!checkConnection()) {
      setError('Impressora desconectada. Reconecte.')
      setIsConnected(false)
      return false
    }

    try {
      const now = new Date()
      const dateStr = now.toLocaleDateString('pt-BR')
      const timeStr = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      const storeName = order.storeName || 'NF PASTELARIA'
      const div = '================================'

      let data = concatBytes(
        CMD.INIT,
        CMD.ALIGN_CENTER,
        CMD.DOUBLE_SIZE,
        CMD.BOLD_ON,
        textToBytes(storeName + '\n'),
        CMD.NORMAL_SIZE,
        CMD.BOLD_OFF,
        textToBytes(div + '\n\n'),
        CMD.DOUBLE_SIZE,
        CMD.BOLD_ON,
        textToBytes(`PEDIDO #${order.id}\n`),
        CMD.NORMAL_SIZE,
        CMD.BOLD_OFF,
        textToBytes(`${dateStr} ${timeStr}\n`),
        textToBytes('--------------------------------\n'),
        CMD.ALIGN_LEFT,
        CMD.BOLD_ON,
        textToBytes('CLIENTE:\n'),
        CMD.BOLD_OFF,
        textToBytes(`${order.customerName}\n`),
      )

      if (order.phone) data = concatBytes(data, textToBytes(`Tel: ${order.phone}\n`))
      if (order.address) data = concatBytes(data, textToBytes(`End: ${order.address}\n`))

      data = concatBytes(data,
        textToBytes('--------------------------------\n'),
        CMD.BOLD_ON,
        textToBytes('ITENS:\n'),
        CMD.BOLD_OFF,
      )

      for (const item of order.items) {
        const itemTotal = (item.price * item.quantity).toFixed(2)
        data = concatBytes(data, textToBytes(`${item.quantity}x ${item.productName}\n   R$ ${itemTotal}\n`))
        if (item.observation) data = concatBytes(data, textToBytes(`   Obs: ${item.observation}\n`))
      }

      data = concatBytes(data,
        textToBytes(div + '\n'),
        CMD.DOUBLE_SIZE,
        CMD.BOLD_ON,
        textToBytes(`TOTAL: R$ ${order.total.toFixed(2)}\n`),
        CMD.NORMAL_SIZE,
        CMD.BOLD_OFF,
        textToBytes(div + '\n'),
      )

      if (order.paymentMethod) data = concatBytes(data, textToBytes(`Pagamento: ${order.paymentMethod}\n`))
      if (order.observation) data = concatBytes(data, CMD.BOLD_ON, textToBytes('OBS: '), CMD.BOLD_OFF, textToBytes(`${order.observation}\n`))

      data = concatBytes(data,
        CMD.FEED_LINE,
        CMD.ALIGN_CENTER,
        textToBytes('Obrigado pela preferencia!\n'),
        textToBytes('Volte sempre!\n'),
        CMD.FEED_LINES(4),
        CMD.CUT,
      )

      const success = await sendData(data)
      if (success) console.log('[Printer] Pedido #' + order.id + ' impresso!')
      return success
    } catch (err: any) {
      setError(err?.message || 'Erro ao imprimir')
      return false
    }
  }, [sendData])

  const disconnect = useCallback(async () => {
    try {
      if (printerRef.current?.device?.gatt?.connected) {
        printerRef.current.device.gatt.disconnect()
      }
      printerRef.current = null
      setIsConnected(false)
      setConnectedDevice(null)
      console.log('[Printer] Desconectado')
    } catch (err) {
      console.error('[Printer] Erro ao desconectar:', err)
    }
  }, [])

  const print = useCallback(async (text: string): Promise<boolean> => {
    if (!printerRef.current || !printerRef.current.characteristic) {
      setError('Impressora desconectada. Reconecte.')
      setIsConnected(false)
      return false
    }
    const data = concatBytes(CMD.INIT, CMD.ALIGN_LEFT, textToBytes(text), CMD.FEED_LINES(3), CMD.CUT)
    return await sendData(data)
  }, [sendData])

  return {
    isConnected,
    error,
    connectedDevice,
    isScanning,
    connectPrinter,
    disconnect,
    print,
    printOrder,
  }
}

export function useWhatsAppMessage() {
  const generateMessage = (
    items: Array<{ product: { name: string; price: number }; quantity: number; observations?: string }>,
    subtotal: number,
    deliveryFee: number,
    total: number,
    customerName: string,
    address: {
      street: string
      number: string
      neighborhood: string
      complement?: string
    },
    paymentMethod: string,
    change?: number
  ) => {
    const paymentMethodMap: Record<string, string> = {
      dinheiro: 'Dinheiro',
      pix: 'PIX',
      credito: 'Cartão de Crédito',
      debito: 'Cartão de Débito',
    }

    let message = '🍽️ *PEDIDO NF PASTELARIA*\n\n'
    message += `👤 *Cliente:* ${customerName}\n\n`
    message += '*Itens do Pedido:*\n'

    items.forEach((item) => {
      message += `• ${item.product.name} (x${item.quantity}) - R$ ${(item.product.price * item.quantity).toFixed(2)}\n`
      if (item.observations) {
        message += `  Obs: ${item.observations}\n`
      }
    })

    message += `\n*Endereço de Entrega:*\n`
    message += `${address.street}, ${address.number}\n`
    message += `${address.neighborhood}\n`
    if (address.complement) {
      message += `${address.complement}\n`
    }

    message += `\n*Resumo:*\n`
    message += `Subtotal: R$ ${subtotal.toFixed(2)}\n`
    message += `Taxa de Entrega: R$ ${deliveryFee.toFixed(2)}\n`
    message += `*Total: R$ ${total.toFixed(2)}*\n\n`
    message += `*Forma de Pagamento:* ${paymentMethodMap[paymentMethod]}\n`

    if (change) {
      message += `*Troco para:* R$ ${change.toFixed(2)}\n`
    }

    return encodeURIComponent(message)
  }

  const generateWhatsAppLink = (
    phone: string,
    message: string
  ) => {
    return `https://wa.me/${phone}?text=${message}`
  }

  return { generateMessage, generateWhatsAppLink }
}

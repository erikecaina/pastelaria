'use client'

export interface LocalOrder {
  id: string
  customerName: string
  phone: string
  address: string
  items: any[]
  total: number
  timestamp: number
  synced: boolean
}

export function useLocalOrders() {
  const STORAGE_KEY = 'pastelaria_orders_queue'

  const addOrder = (order: Omit<LocalOrder, 'id' | 'timestamp' | 'synced'>) => {
    try {
      const orders = getOrders()
      const newOrder: LocalOrder = {
        ...order,
        id: Date.now().toString(),
        timestamp: Date.now(),
        synced: false,
      }
      orders.push(newOrder)
      localStorage.setItem(STORAGE_KEY, JSON.stringify(orders))
      console.log('[v0] Pedido salvo localmente:', newOrder.id)
      return newOrder
    } catch (e) {
      console.error('[v0] Erro ao salvar localmente:', e)
      return null
    }
  }

  const getOrders = (): LocalOrder[] => {
    try {
      const data = localStorage.getItem(STORAGE_KEY)
      return data ? JSON.parse(data) : []
    } catch (e) {
      console.error('[v0] Erro ao ler ordens locais:', e)
      return []
    }
  }

  const markAsSynced = (orderId: string) => {
    try {
      const orders = getOrders()
      const updated = orders.map(o => 
        o.id === orderId ? { ...o, synced: true } : o
      )
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
    } catch (e) {
      console.error('[v0] Erro ao marcar como sincronizado:', e)
    }
  }

  const syncOrders = async () => {
    const orders = getOrders()
    const unsynced = orders.filter(o => !o.synced)

    for (const order of unsynced) {
      try {
        const response = await fetch('/api/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            customerName: order.customerName,
            phone: order.phone,
            address: order.address,
            items: order.items,
            total: order.total,
          }),
        })

        if (response.ok) {
          markAsSynced(order.id)
          console.log('[v0] Pedido sincronizado:', order.id)
        }
      } catch (e) {
        console.error('[v0] Erro ao sincronizar:', e)
      }
    }
  }

  return { addOrder, getOrders, markAsSynced, syncOrders }
}

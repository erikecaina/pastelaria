'use client'

import useSWR from 'swr'
import { useState, useCallback } from 'react'

export interface Order {
  id: string
  customerName: string
  phone: string
  address: string
  items: any[]
  total: number
  status: 'pendente' | 'impresso' | 'entregue'
  created_at: string
}

const fetcher = async (url: string) => {
  const response = await fetch(url)
  if (!response.ok) {
    throw new Error('Failed to fetch orders')
  }
  const data = await response.json()
  return data.orders || []
}

export function useOrdersSimple() {
  const [localOrders, setLocalOrders] = useState<Order[]>([])
  
  // Fetch da API com SWR - revalida a cada 2 segundos
  const { data: apiOrders = [], mutate } = useSWR(
    '/api/admin/orders',
    fetcher,
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: true,
      dedupingInterval: 1000,
      focusThrottleInterval: 5000,
      refreshInterval: 2000, // Recarrega a cada 2 segundos
    }
  )

  // Transformar pedidos da API
  const orders = (apiOrders || []).map((order: any) => ({
    id: order.id,
    customerName: order.customer_name || 'Sem nome',
    phone: order.customer_phone || order.phone || '',
    address: order.customer_address || order.address || '',
    items: typeof order.items === 'string' ? JSON.parse(order.items) : (order.items || []),
    total: order.total || 0,
    status: order.status || 'pendente',
    created_at: order.created_at || new Date().toISOString(),
  }))

  const updateOrderStatus = useCallback(async (orderId: string, newStatus: string) => {
    try {
      const response = await fetch('/api/orders/update-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId, status: newStatus }),
      })

      if (response.ok) {
        // Revalidar dados da API para mostrar mudança
        await mutate()
      }
    } catch (error) {
      console.error('Erro ao atualizar status:', error)
    }
  }, [mutate])

  const addOrder = useCallback((order: Omit<Order, 'id' | 'status' | 'created_at'>) => {
    // Adicionar localmente para feedback imediato
    const newOrder: Order = {
      ...order,
      id: `temp-${Date.now()}`,
      status: 'pendente',
      created_at: new Date().toISOString(),
    }
    setLocalOrders([newOrder, ...localOrders])
    // Depois revalidar da API
    setTimeout(() => mutate(), 500)
  }, [localOrders, mutate])

  return {
    orders: orders.length > 0 ? orders : localOrders,
    updateOrderStatus,
    addOrder,
    isLoading: !apiOrders,
    mutate,
  }
}

'use client'

import { useState, useEffect } from 'react'
import { Product, Order } from '@/lib/types'
import { defaultProducts } from '@/lib/store-data'

export function useAdminData() {
  const [products, setProducts] = useState<Product[]>(defaultProducts)
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const storedProducts = localStorage.getItem('admin_products')
    const storedOrders = localStorage.getItem('admin_orders')

    if (storedProducts) {
      setProducts(JSON.parse(storedProducts))
    }
    if (storedOrders) {
      setOrders(JSON.parse(storedOrders))
    }
    setIsLoading(false)
  }, [])

  const saveProducts = (newProducts: Product[]) => {
    setProducts(newProducts)
    localStorage.setItem('admin_products', JSON.stringify(newProducts))
  }

  const saveOrders = (newOrders: Order[]) => {
    setOrders(newOrders)
    localStorage.setItem('admin_orders', JSON.stringify(newOrders))
  }

  const addProduct = (product: Product) => {
    const newProducts = [...products, product]
    saveProducts(newProducts)
    return product
  }

  const updateProduct = (id: string, updates: Partial<Product>) => {
    const newProducts = products.map((p) =>
      p.id === id ? { ...p, ...updates } : p
    )
    saveProducts(newProducts)
  }

  const deleteProduct = (id: string) => {
    const newProducts = products.filter((p) => p.id !== id)
    saveProducts(newProducts)
  }

  return {
    products,
    orders,
    isLoading,
    addProduct,
    updateProduct,
    deleteProduct,
    saveOrders,
  }
}

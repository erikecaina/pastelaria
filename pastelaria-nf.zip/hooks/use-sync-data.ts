import { useEffect, useState, useRef, useCallback } from 'react'

/**
 * Hook para sincronizar dados em tempo real via localStorage
 * Atualiza automaticamente a cada 2 segundos
 */
export function useSyncData<T>(
  key: string,
  defaultValue: T,
  interval: number = 2000
): [T, (data: T) => void] {
  const [data, setData] = useState<T>(defaultValue)
  const [mounted, setMounted] = useState(false)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  // Carregar dados iniciais do localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(key)
      if (stored) {
        const parsed = JSON.parse(stored)
        setData(parsed)
      }
    } catch (error) {
      console.error(`[v0] Erro ao carregar ${key}:`, error)
    }
    setMounted(true)
  }, [key])

  // Configurar polling para sincronização em tempo real
  useEffect(() => {
    if (!mounted) return

    const syncData = () => {
      try {
        const stored = localStorage.getItem(key)
        if (stored) {
          const parsed = JSON.parse(stored)
          setData(parsed)
        }
      } catch (error) {
        console.error(`[v0] Erro ao sincronizar ${key}:`, error)
      }
    }

    // Sincronizar imediatamente
    syncData()

    // Configurar intervalo de sincronização
    intervalRef.current = setInterval(syncData, interval)

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [key, interval, mounted])

  // Função para atualizar dados
  const updateData = useCallback((newData: T) => {
    try {
      setData(newData)
      localStorage.setItem(key, JSON.stringify(newData))
    } catch (error) {
      console.error(`[v0] Erro ao atualizar ${key}:`, error)
    }
  }, [key])

  return [data, updateData]
}

'use client'

import { createContext, useContext, useState, useEffect } from 'react'
import { CartItem, Product } from '@/lib/types'

type CartContextType = {
  items: CartItem[]
  addItem: (product: Product, quantity: number, size?: string, observations?: string) => void
  removeItem: (productId: string) => void
  updateQuantity: (productId: string, quantity: number) => void
  clearCart: () => void
  total: number
  subtotal: number
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [mounted, setMounted] = useState(false)
  const DELIVERY_FEE = 2.0

  // Carregar itens do localStorage na inicialização
  useEffect(() => {
    try {
      const saved = localStorage.getItem('nf_pastelaria_cart')
      if (saved) {
        const parsedItems = JSON.parse(saved)
        setItems(parsedItems)
      }
    } catch (error) {
      console.error('[v0] Erro ao carregar carrinho:', error)
    }
    setMounted(true)
  }, [])

  // Salvar itens no localStorage sempre que mudarem
  useEffect(() => {
    if (mounted) {
      try {
        localStorage.setItem('nf_pastelaria_cart', JSON.stringify(items))
      } catch (error) {
        console.error('[v0] Erro ao salvar carrinho:', error)
      }
    }
  }, [items, mounted])

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
  const total = subtotal + DELIVERY_FEE

  const addItem = (product: Product, quantity: number, size?: string, observations?: string) => {
    setItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id)
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        )
      }
      return [...prev, { product, quantity, size: size as any, observations }]
    })
  }

  const removeItem = (productId: string) => {
    setItems((prev) => prev.filter((item) => item.product.id !== productId))
  }

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(productId)
    } else {
      setItems((prev) =>
        prev.map((item) =>
          item.product.id === productId ? { ...item, quantity } : item
        )
      )
    }
  }

  const clearCart = () => {
    setItems([])
  }

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        total,
        subtotal,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error('useCart must be used within CartProvider')
  }
  return context
}

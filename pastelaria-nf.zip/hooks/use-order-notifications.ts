import { useEffect, useState } from 'react'

interface OrderData {
  id: string
  customerName: string
  phone: string
  address: string
  items: Array<{ productName: string; quantity: number; price: number }>
  total: number
  date: Date
  status: 'pendente' | 'impresso' | 'entregue'
}

export function useOrderNotifications(soundEnabled: boolean) {
  const [orders, setOrders] = useState<OrderData[]>([])
  const [lastOrderId, setLastOrderId] = useState<string>('')

  useEffect(() => {
    // Simular recebimento de pedidos via WebSocket/polling
    const checkForNewOrders = () => {
      // Recuperar pedidos do localStorage
      const storedOrders = localStorage.getItem('admin_orders')
      const parsedOrders = storedOrders ? JSON.parse(storedOrders) : []

      if (parsedOrders.length > 0) {
        const latestOrder = parsedOrders[parsedOrders.length - 1]

        // Se é um novo pedido
        if (latestOrder.id !== lastOrderId) {
          setLastOrderId(latestOrder.id)

          // Reproduzir som de notificação
          if (soundEnabled) {
            playNotificationSound()
          }

          // Imprimir automaticamente
          console.log('[v0] Novo pedido recebido:', latestOrder)
          printOrder(latestOrder)
        }
      }

      setOrders(parsedOrders)
    }

    checkForNewOrders()

    // Verificar novos pedidos a cada 5 segundos
    const interval = setInterval(checkForNewOrders, 5000)

    return () => clearInterval(interval)
  }, [soundEnabled, lastOrderId])

  const playNotificationSound = () => {
    try {
      // Criar som de notificação usando Web Audio API
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
      const gainNode = audioContext.createGain()

      gainNode.connect(audioContext.destination)

      // Primeiro bip - 800Hz
      const osc1 = audioContext.createOscillator()
      osc1.frequency.value = 800
      osc1.connect(gainNode)
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1)
      osc1.start(audioContext.currentTime)
      osc1.stop(audioContext.currentTime + 0.1)

      // Segundo bip - 1000Hz
      const osc2 = audioContext.createOscillator()
      osc2.frequency.value = 1000
      osc2.connect(gainNode)
      osc2.start(audioContext.currentTime + 0.15)
      osc2.stop(audioContext.currentTime + 0.25)

      // Terceiro bip - 800Hz
      const osc3 = audioContext.createOscillator()
      osc3.frequency.value = 800
      osc3.connect(gainNode)
      osc3.start(audioContext.currentTime + 0.3)
      osc3.stop(audioContext.currentTime + 0.4)
    } catch (error) {
      console.error('[v0] Erro ao reproduzir som:', error)
    }
  }

  const printOrder = async (order: OrderData) => {
    console.log('[v0] Enviando pedido para impressora:', order)

    // Aqui você integraria com a API da impressora Bluetooth
    // Por enquanto, apenas logamos
    try {
      // Exemplo de como seria a chamada à impressora
      const printContent = formatOrderForPrint(order)
      console.log('[v0] Conteúdo para impressão:', printContent)

      // Em uma implementação real:
      // await fetch('/api/printer/print', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ content: printContent })
      // })
    } catch (error) {
      console.error('[v0] Erro ao imprimir pedido:', error)
    }
  }

  const formatOrderForPrint = (order: OrderData) => {
    let content = 'NF PASTELARIA\n'
    content += '='.repeat(32) + '\n'
    content += `Pedido #${order.id}\n`
    content += `Data: ${new Date(order.date).toLocaleString('pt-BR')}\n`
    content += '='.repeat(32) + '\n'
    content += `Cliente: ${order.customerName}\n`
    content += `Telefone: ${order.phone}\n`
    content += `Endereço: ${order.address}\n`
    content += '='.repeat(32) + '\n'
    content += 'ITENS:\n'

    order.items.forEach((item) => {
      content += `${item.quantity}x ${item.productName}\n`
      content += `   R$ ${(item.price * item.quantity).toFixed(2)}\n`
    })

    content += '='.repeat(32) + '\n'
    content += `TOTAL: R$ ${order.total.toFixed(2)}\n`
    content += '='.repeat(32) + '\n'

    return content
  }

  return { orders, playNotificationSound, printOrder }
}

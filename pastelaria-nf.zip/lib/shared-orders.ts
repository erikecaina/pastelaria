// Sistema de sincronização de pedidos entre múltiplos dispositivos
// Usa localStorage como banco de dados central que todos os dispositivos consultam

const SHARED_ORDERS_KEY = 'nf_pastelaria_orders_shared'

export interface SharedOrder {
  id: string
  customerName: string
  phone: string
  address: string
  items: Array<{ productName: string; quantity: number; price: number }>
  total: number
  date: string
  status: 'pendente' | 'impresso' | 'entregue'
  timestamp: number
  deviceId: string // ID do dispositivo que criou o pedido
}

// Gera um ID único para este dispositivo
function getDeviceId(): string {
  let deviceId = localStorage.getItem('device_id')
  if (!deviceId) {
    deviceId = `device_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    localStorage.setItem('device_id', deviceId)
  }
  return deviceId
}

export function getSharedOrders(): SharedOrder[] {
  try {
    const stored = localStorage.getItem(SHARED_ORDERS_KEY)
    if (stored) {
      return JSON.parse(stored)
    }
  } catch (error) {
    console.error('[v0] Erro ao carregar pedidos compartilhados:', error)
  }
  return []
}

export function addSharedOrder(order: Omit<SharedOrder, 'id' | 'timestamp' | 'deviceId'>): SharedOrder {
  const deviceId = getDeviceId()
  const newOrder: SharedOrder = {
    ...order,
    id: `order_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    timestamp: Date.now(),
    deviceId,
  }

  try {
    const orders = getSharedOrders()
    const updated = [newOrder, ...orders]
    localStorage.setItem(SHARED_ORDERS_KEY, JSON.stringify(updated))

    // Sincroniza também com admin_orders para compatibilidade
    localStorage.setItem('admin_orders', JSON.stringify(updated))

    console.log('[v0] Pedido compartilhado criado:', newOrder)

    // Dispara eventos para outras abas
    window.dispatchEvent(
      new CustomEvent('sharedOrdersUpdated', {
        detail: { orders: updated, newOrder }
      })
    )

    return newOrder
  } catch (error) {
    console.error('[v0] Erro ao adicionar pedido compartilhado:', error)
    throw error
  }
}

export function updateSharedOrderStatus(
  orderId: string,
  status: SharedOrder['status']
): void {
  try {
    const orders = getSharedOrders()
    const updated = orders.map((order) =>
      order.id === orderId ? { ...order, status, timestamp: Date.now() } : order
    )
    localStorage.setItem(SHARED_ORDERS_KEY, JSON.stringify(updated))
    localStorage.setItem('admin_orders', JSON.stringify(updated))

    window.dispatchEvent(
      new CustomEvent('sharedOrdersUpdated', {
        detail: { orders: updated }
      })
    )
  } catch (error) {
    console.error('[v0] Erro ao atualizar pedido compartilhado:', error)
  }
}

export function listenToSharedOrders(callback: (orders: SharedOrder[]) => void): () => void {
  const handleUpdate = () => {
    const orders = getSharedOrders()
    callback(orders)
  }

  // Escuta eventos customizados
  window.addEventListener('sharedOrdersUpdated', handleUpdate)

  // Polling a cada 1 segundo para pegar mudanças de outros dispositivos
  const interval = setInterval(handleUpdate, 1000)

  // Função para parar de ouvir
  return () => {
    window.removeEventListener('sharedOrdersUpdated', handleUpdate)
    clearInterval(interval)
  }
}

// Serviço de sincronização de pedidos entre dispositivos
// Usa um sistema baseado em IndexedDB (que funciona melhor entre abas e seria mais escalável)
// ou localStorage com um mecanismo de heartbeat para detectar mudanças

export interface SyncedOrder {
  id: string
  customerName: string
  phone: string
  address: string
  items: Array<{ productName: string; quantity: number; price: number }>
  total: number
  date: string
  status: 'pendente' | 'aceito' | 'em_preparo' | 'pronto' | 'entregue'
  timestamp: number // Para ordenação mais precisa
}

// Chave para armazenar o timestamp da última sincronização
const SYNC_TIMESTAMP_KEY = 'nf_orders_sync_timestamp'
const ORDERS_KEY = 'admin_orders'

export function getAllOrders(): SyncedOrder[] {
  try {
    const stored = localStorage.getItem(ORDERS_KEY)
    if (stored) {
      return JSON.parse(stored)
    }
  } catch (error) {
    console.error('[v0] Erro ao carregar pedidos sincronizados:', error)
  }
  return []
}

export function addSyncedOrder(order: SyncedOrder): void {
  try {
    const orders = getAllOrders()
    const updated = [order, ...orders] // Novo pedido em primeiro lugar
    localStorage.setItem(ORDERS_KEY, JSON.stringify(updated))
    localStorage.setItem(SYNC_TIMESTAMP_KEY, Date.now().toString())
    
    // Dispara um evento customizado para notificar outras abas/janelas
    window.dispatchEvent(
      new CustomEvent('ordersUpdated', {
        detail: { orders: updated, timestamp: Date.now() }
      })
    )
  } catch (error) {
    console.error('[v0] Erro ao adicionar pedido sincronizado:', error)
  }
}

export function updateSyncedOrderStatus(
  orderId: string,
  status: SyncedOrder['status']
): void {
  try {
    const orders = getAllOrders()
    const updated = orders.map((order) =>
      order.id === orderId ? { ...order, status } : order
    )
    localStorage.setItem(ORDERS_KEY, JSON.stringify(updated))
    localStorage.setItem(SYNC_TIMESTAMP_KEY, Date.now().toString())
    
    window.dispatchEvent(
      new CustomEvent('ordersUpdated', {
        detail: { orders: updated, timestamp: Date.now() }
      })
    )
  } catch (error) {
    console.error('[v0] Erro ao atualizar status do pedido:', error)
  }
}

export function listenToOrderChanges(callback: (orders: SyncedOrder[]) => void): () => void {
  const handleChange = () => {
    const orders = getAllOrders()
    callback(orders)
  }

  // Escuta eventos customizados de mudanças
  window.addEventListener('ordersUpdated', handleChange)

  // Também faz polling para pegar mudanças de outras abas
  const interval = setInterval(() => {
    const lastSync = localStorage.getItem(SYNC_TIMESTAMP_KEY)
    if (lastSync) {
      const orders = getAllOrders()
      callback(orders)
    }
  }, 1000) // Polling a cada 1 segundo

  // Retorna função para parar de ouvir
  return () => {
    window.removeEventListener('ordersUpdated', handleChange)
    clearInterval(interval)
  }
}

export type Product = {
  id: string
  name: string
  description: string
  price: number
  image?: string
  category: 'salgados' | 'doces' | 'bebidas'
  active: boolean
}

export type CartItem = {
  product: Product
  quantity: number
  size?: 'pequeno' | 'medio' | 'grande'
  observations?: string
}

export type Order = {
  id: string
  items: CartItem[]
  subtotal: number
  deliveryFee: number
  total: number
  customerName: string
  address: {
    street: string
    number: string
    neighborhood: string
    complement?: string
  }
  paymentMethod: 'dinheiro' | 'pix' | 'credito' | 'debito'
  change?: number
  wantChange: boolean
  timestamp: Date
}

// Sistema de fila de pedidos para fallback
let ordersQueue: any[] = []

export async function addOrderToQueue(order: any) {
  ordersQueue.push({
    ...order,
    queuedAt: new Date().toISOString(),
    retries: 0,
  })
  
  // Tentar sincronizar imediatamente
  syncQueue()
}

export async function syncQueue() {
  if (ordersQueue.length === 0) return

  const order = ordersQueue[0]
  
  try {
    const response = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(order),
    })

    if (response.ok) {
      // Removeu da fila se sucesso
      ordersQueue.shift()
    } else {
      // Incrementar retries
      order.retries = (order.retries || 0) + 1
      
      // Se atingir 5 tentativas, usar backup
      if (order.retries >= 5) {
        try {
          await fetch('/api/orders-backup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(order),
          })
          ordersQueue.shift()
        } catch {
          // Deixar na fila para próxima tentativa
        }
      }
    }
  } catch (error) {
    order.retries = (order.retries || 0) + 1
    console.error('[v0] Error syncing queue:', error)
  }
}

// Sincronizar fila a cada 2 segundos
if (typeof window !== 'undefined') {
  setInterval(syncQueue, 2000)
}

export function getQueueSize() {
  return ordersQueue.length
}

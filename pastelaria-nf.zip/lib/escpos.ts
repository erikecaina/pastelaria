// Comandos ESC/POS
export const ESC_POS = {
  ALIGN_LEFT: Buffer.from([0x1b, 0x61, 0x00]),
  ALIGN_CENTER: Buffer.from([0x1b, 0x61, 0x01]),
  ALIGN_RIGHT: Buffer.from([0x1b, 0x61, 0x02]),
  
  TEXT_SIZE_NORMAL: Buffer.from([0x1d, 0x21, 0x00]),
  TEXT_SIZE_DOUBLE: Buffer.from([0x1d, 0x21, 0x11]),
  TEXT_SIZE_DOUBLE_WIDTH: Buffer.from([0x1d, 0x21, 0x10]),
  TEXT_SIZE_DOUBLE_HEIGHT: Buffer.from([0x1d, 0x21, 0x01]),
  
  BOLD_ON: Buffer.from([0x1b, 0x45, 0x01]),
  BOLD_OFF: Buffer.from([0x1b, 0x45, 0x00]),
  
  FEED_LINE: Buffer.from([0x0a]),
  FEED_LINES_3: Buffer.from([0x1b, 0x64, 0x03]),
  
  CUT_PAPER: Buffer.from([0x1d, 0x56, 0x01]),
  DRAWER_KICK: Buffer.from([0x1b, 0x70, 0x00, 0x3c, 0x19]),
}

export function textToBytes(text: string): Buffer {
  return Buffer.from(text + '\n', 'utf-8')
}

export function formatOrderForPrint(order: any, storeName: string = 'NF Pastelaria'): Buffer {
  const lines: Buffer[] = []

  // Header - Nome da loja
  lines.push(ESC_POS.ALIGN_CENTER)
  lines.push(ESC_POS.TEXT_SIZE_DOUBLE)
  lines.push(ESC_POS.BOLD_ON)
  lines.push(textToBytes(storeName))
  lines.push(ESC_POS.BOLD_OFF)
  lines.push(ESC_POS.TEXT_SIZE_NORMAL)
  lines.push(ESC_POS.FEED_LINE)

  // Número e data do pedido
  lines.push(ESC_POS.ALIGN_CENTER)
  lines.push(ESC_POS.BOLD_ON)
  lines.push(textToBytes(`PEDIDO #${order.id?.substring(0, 8) || 'N/A'}`))
  lines.push(ESC_POS.BOLD_OFF)
  
  const orderDate = new Date(order.created_at).toLocaleString('pt-BR')
  lines.push(textToBytes(orderDate))
  lines.push(ESC_POS.FEED_LINE)

  // Dados do cliente
  lines.push(ESC_POS.ALIGN_LEFT)
  lines.push(ESC_POS.BOLD_ON)
  lines.push(textToBytes('CLIENTE:'))
  lines.push(ESC_POS.BOLD_OFF)
  lines.push(textToBytes(order.customer_name || 'N/A'))
  lines.push(textToBytes(`Tel: ${order.customer_phone || 'N/A'}`))
  lines.push(textToBytes(`End: ${order.customer_address || 'N/A'}`))
  lines.push(ESC_POS.FEED_LINE)

  // Tipo de entrega
  const pickupText = order.will_pickup ? 'RETIRADA' : 'ENTREGA'
  lines.push(ESC_POS.ALIGN_CENTER)
  lines.push(ESC_POS.BOLD_ON)
  lines.push(textToBytes(pickupText))
  lines.push(ESC_POS.BOLD_OFF)
  lines.push(ESC_POS.FEED_LINE)

  // Itens do pedido
  lines.push(ESC_POS.ALIGN_LEFT)
  lines.push(ESC_POS.BOLD_ON)
  lines.push(textToBytes('ITENS:'))
  lines.push(ESC_POS.BOLD_OFF)
  
  const items = Array.isArray(order.items) ? order.items : []
  items.forEach((item: any) => {
    const itemName = item.productName || item.name || 'Item'
    const quantity = item.quantity || 1
    const line = `${quantity}x ${itemName}`
    lines.push(textToBytes(line))
    
    if (item.observation) {
      lines.push(textToBytes(`  Obs: ${item.observation}`))
    }
  })
  lines.push(ESC_POS.FEED_LINE)

  // Total
  lines.push(ESC_POS.ALIGN_RIGHT)
  lines.push(ESC_POS.TEXT_SIZE_DOUBLE)
  lines.push(ESC_POS.BOLD_ON)
  lines.push(textToBytes(`Total: R$ ${(order.total || 0).toFixed(2)}`))
  lines.push(ESC_POS.BOLD_OFF)
  lines.push(ESC_POS.TEXT_SIZE_NORMAL)
  lines.push(ESC_POS.FEED_LINES_3)

  // Rodapé
  lines.push(ESC_POS.ALIGN_CENTER)
  lines.push(textToBytes('Obrigado pela compra!'))
  lines.push(ESC_POS.FEED_LINES_3)

  // Cortar papel
  lines.push(ESC_POS.CUT_PAPER)

  return Buffer.concat(lines)
}

export async function sendToPrinter(device: any, data: Buffer) {
  try {
    const characteristic = device.characteristic
    if (!characteristic) {
      throw new Error('Característica não encontrada')
    }

    // Dividir em chunks de 200 bytes (limite Bluetooth)
    for (let i = 0; i < data.length; i += 200) {
      const chunk = data.slice(i, i + 200)
      await characteristic.writeValue(chunk)
      
      // Aguardar 20ms antes do próximo chunk
      await new Promise(r => setTimeout(r, 20))
    }

    console.log('[v0] Dados enviados para impressora com sucesso')
    return true
  } catch (error) {
    console.error('[v0] Erro ao enviar para impressora:', error)
    throw error
  }
}

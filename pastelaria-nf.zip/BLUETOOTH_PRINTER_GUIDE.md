# Guia de Conexão - Impressora MP-58C7 via Bluetooth

## ⚠️ REQUISITOS IMPORTANTES

### 1. **Navegador Correto**
Você **PRECISA** usar um destes navegadores:
- ✅ **Google Chrome** (recomendado)
- ✅ **Microsoft Edge**
- ✅ **Opera**
- ✅ **Brave**

❌ NÃO funciona em: Firefox, Safari, Internet Explorer

### 2. **Impressora MP-58C7**
- Deve estar **LIGADA**
- Deve estar em **MODO PAREAMENTO** (geralmente mantém o botão pressionado por 3-5 segundos até piscar)
- Deve estar a menos de 10 metros do computador

### 3. **Bluetooth do Sistema Operacional**
A impressora **DEVE ser pareada primeiro no seu sistema operacional**:

#### Windows:
1. Abra Configurações → Bluetooth e dispositivos
2. Clique "Adicionar dispositivo"
3. Selecione "Bluetooth"
4. Procure por "MP-58C7" ou dispositivos Bluetooth
5. Clique e espere conectar

#### macOS:
1. Abra Preferências do Sistema → Bluetooth
2. Certifique-se que Bluetooth está ativado
3. Procure por "MP-58C7"
4. Clique e autorize a conexão

#### Linux:
Use `bluetoothctl` ou um gerenciador de Bluetooth graficamente

## 📋 PASSOS PARA CONECTAR NA NF PASTELARIA

### Passo 1: Preparar a Impressora
1. Verifique se a impressora está **ligada**
2. Coloque a impressora em **modo pareamento** (procure instruções específicas do modelo)
3. Certifique-se de que a impressora já foi pareada com seu computador

### Passo 2: Abrir o Sistema
1. Abra o navegador **Chrome**, **Edge** ou **Opera**
2. Acesse: `http://localhost:3000/admin/pedidos`
3. Vá até a seção **"Impressora Bluetooth"**

### Passo 3: Conectar
1. Clique no botão roxo **"Conectar Impressora"**
2. Espere a caixa de diálogo do navegador aparecer
3. **Selecione a MP-58C7** na lista de dispositivos
4. Clique **"Parear"** (se solicitado pelo navegador)

### Passo 4: Confirmação
- Status deve mudar para **"Conectada"** (verde)
- Você verá o nome da impressora: **"MP-58C7"** ou similar

## ❌ PROBLEMAS COMUNS

### "Web Bluetooth não é suportado"
**Solução:** Use Chrome, Edge ou Opera. Firefox e Safari não suportam Web Bluetooth.

### "Nenhuma impressora encontrada"
**Verificações:**
1. A impressora está ligada?
2. A impressora está em modo pareamento?
3. A impressora já foi pareada com seu computador?
4. Reinicie a impressora e tente novamente

### "Erro de conectividade"
**Solução:**
1. Desligue a impressora
2. Aguarde 30 segundos
3. Ligue novamente
4. Coloque em modo pareamento
5. Tente conectar novamente

### "Dispositivo desconectado"
**Solução:**
- Verifique se a impressora ainda está ligada
- Aproxime a impressora do computador
- Tente conectar novamente

## 🖨️ TESTANDO A IMPRESSÃO

Após conectar com sucesso:
1. Crie ou selecione um pedido
2. Clique no botão **"Imprimir"**
3. A impressora deve começar a imprimir

## 📝 FORMATOS DE IMPRESSÃO

A impressora imprime em formato de recibo com:
- Número do pedido
- Data e hora
- Dados do cliente
- Lista de itens
- Total do pedido
- Mensagem de agradecimento

## 🔧 DADOS TÉCNICOS

- **Modelo:** MP-58C7
- **Tipo:** Impressora Térmica Bluetooth
- **Largura:** 80mm
- **Interface:** Bluetooth (SPP - Serial Port Profile)
- **Baud Rate:** 9600
- **Protocolo:** ESC/POS

## ⚡ DICAS

1. **Reconexão automática:** Uma vez conectada, a impressora será reconectada automaticamente na próxima vez que você usar o sistema
2. **Histórico:** O sistema mantém histórico de impressoras pareadas para acesso rápido
3. **Múltiplas impressoras:** Você pode conectar a diferentes impressoras, mas apenas uma por vez

## 📞 SUPORTE

Se o sistema ainda não conectar:
1. Verifique o console do navegador (F12) para mensagens de erro
2. Reinicie o navegador
3. Reinicie o computador
4. Verifique se há atualizações do firmware da impressora disponíveis
